<?php
/**
 * Plugin Name: Bridge MLS Search
 * Plugin URI: https://yourwebsite.com
 * Description: WordPress plugin to search and display MLS listings using Bridge Web API
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('BRIDGE_MLS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BRIDGE_MLS_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('BRIDGE_MLS_VERSION', '1.0.0');

// Main plugin class
class BridgeMLSPlugin {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_mls_search', array($this, 'ajax_search'));
        add_action('wp_ajax_nopriv_mls_search', array($this, 'ajax_search'));
        add_action('wp_ajax_mls_get_towns', array($this, 'ajax_get_towns'));
        add_action('wp_ajax_nopriv_mls_get_towns', array($this, 'ajax_get_towns'));
        
        // Register shortcodes
        add_shortcode('mls_search', array($this, 'search_form_shortcode'));
        add_shortcode('mls_results', array($this, 'results_shortcode'));
        
        // Add custom rewrite rules
        add_action('init', array($this, 'add_rewrite_rules'));
        add_filter('query_vars', array($this, 'add_query_vars'));
        add_action('template_redirect', array($this, 'handle_search_page'));
        
        // Create database tables on activation
        register_activation_hook(__FILE__, array($this, 'create_tables'));
        
        // Add admin notices for missing dependencies
        add_action('admin_notices', array($this, 'admin_notices'));
    }
    
    public function init() {
        // Include required files
        require_once BRIDGE_MLS_PLUGIN_PATH . 'includes/class-bridge-api.php';
        require_once BRIDGE_MLS_PLUGIN_PATH . 'includes/class-search-form.php';
        require_once BRIDGE_MLS_PLUGIN_PATH . 'includes/class-results-display.php';
        require_once BRIDGE_MLS_PLUGIN_PATH . 'includes/class-property-details.php';
        
        // Include admin debug class if in admin
        if (is_admin()) {
            require_once BRIDGE_MLS_PLUGIN_PATH . 'includes/class-admin-debug.php';
            new BridgeMLSAdminDebug();
        }
    }
    
    public function enqueue_scripts() {
        wp_enqueue_script('jquery');
        wp_enqueue_script(
            'bridge-mls-script',
            BRIDGE_MLS_PLUGIN_URL . 'assets/js/bridge-mls.js',
            array('jquery'),
            BRIDGE_MLS_VERSION,
            true
        );
        
        wp_enqueue_style(
            'bridge-mls-style',
            BRIDGE_MLS_PLUGIN_URL . 'assets/css/bridge-mls.css',
            array(),
            BRIDGE_MLS_VERSION
        );
        
        // Localize script for AJAX
        wp_localize_script('bridge-mls-script', 'bridge_mls_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bridge_mls_nonce')
        ));
    }
    
    public function ajax_search() {
        check_ajax_referer('bridge_mls_nonce', 'nonce');
        
        $api = new BridgeAPI();
        $filters = $_POST['filters'] ?? array();
        $page = intval($_POST['page'] ?? 1);
        
        $results = $api->search_properties($filters, $page);
        
        wp_send_json_success($results);
    }
    
    public function ajax_get_towns() {
        check_ajax_referer('bridge_mls_nonce', 'nonce');
        
        $api = new BridgeAPI();
        $state = $_POST['state'] ?? 'MA';
        $coverage_area = $_POST['coverage_area'] ?? 'Eastern Mass';
        
        $towns = $api->get_towns($state, $coverage_area);
        
        wp_send_json_success($towns);
    }
    
    public function search_form_shortcode($atts) {
        $search_form = new SearchForm();
        return $search_form->render($atts);
    }
    
    public function results_shortcode($atts) {
        $results_display = new ResultsDisplay();
        return $results_display->render($atts);
    }
    
    public function add_rewrite_rules() {
        add_rewrite_rule(
            '^mls-search/?$',
            'index.php?mls_search=1',
            'top'
        );
        add_rewrite_rule(
            '^mls-property/([^/]+)/?$',
            'index.php?mls_property=$matches[1]',
            'top'
        );
    }
    
    public function add_query_vars($vars) {
        $vars[] = 'mls_search';
        $vars[] = 'mls_property';
        return $vars;
    }
    
    public function handle_search_page() {
        if (get_query_var('mls_search')) {
            $this->load_search_template();
        } elseif (get_query_var('mls_property')) {
            $this->load_property_template();
        }
    }
    
    private function load_search_template() {
        $template = BRIDGE_MLS_PLUGIN_PATH . 'templates/search-page.php';
        if (file_exists($template)) {
            include $template;
            exit;
        }
    }
    
    private function load_property_template() {
        $template = BRIDGE_MLS_PLUGIN_PATH . 'templates/property-details.php';
        if (file_exists($template)) {
            include $template;
            exit;
        }
    }
    
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Create table for cached properties
        $table_name = $wpdb->prefix . 'bridge_mls_properties';
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            listing_key varchar(50) NOT NULL,
            property_data longtext NOT NULL,
            last_updated datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY listing_key (listing_key)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Create table for saved searches
        $table_name = $wpdb->prefix . 'bridge_mls_saved_searches';
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            user_id mediumint(9) NOT NULL,
            search_name varchar(100) NOT NULL,
            search_criteria longtext NOT NULL,
            created_date datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        dbDelta($sql);
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    public function admin_notices() {
        // Check if required files exist
        $required_files = array(
            'includes/class-bridge-api.php',
            'includes/class-search-form.php',
            'includes/class-results-display.php',
            'includes/class-property-details.php',
            'assets/css/bridge-mls.css',
            'assets/js/bridge-mls.js'
        );
        
        $missing_files = array();
        foreach ($required_files as $file) {
            if (!file_exists(BRIDGE_MLS_PLUGIN_PATH . $file)) {
                $missing_files[] = $file;
            }
        }
        
        if (!empty($missing_files)) {
            echo '<div class="notice notice-error"><p>';
            echo '<strong>Bridge MLS Plugin:</strong> Missing required files: ';
            echo implode(', ', $missing_files);
            echo '</p></div>';
        }
        
        // Check for cURL support
        if (!function_exists('curl_version')) {
            echo '<div class="notice notice-warning"><p>';
            echo '<strong>Bridge MLS Plugin:</strong> cURL is not enabled. The plugin may not work properly without cURL support.';
            echo '</p></div>';
        }
        
        // Check for OpenSSL
        if (!extension_loaded('openssl')) {
            echo '<div class="notice notice-warning"><p>';
            echo '<strong>Bridge MLS Plugin:</strong> OpenSSL is not enabled. HTTPS API requests may fail.';
            echo '</p></div>';
        }
        
        // Show debug link
        if (current_user_can('manage_options')) {
            $debug_url = admin_url('tools.php?page=bridge-mls-debug');
            echo '<div class="notice notice-info"><p>';
            echo '<strong>Bridge MLS Plugin:</strong> Use the <a href="' . $debug_url . '">debug page</a> to test your API connection.';
            echo '</p></div>';
        }
    }
}

// Initialize the plugin
new BridgeMLSPlugin();

/**
 * Plugin activation hook
 */
function bridge_mls_activate() {
    // Create database tables
    $plugin = new BridgeMLSPlugin();
    $plugin->create_tables();
    
    // Set default options
    add_option('bridge_mls_version', BRIDGE_MLS_VERSION);
    add_option('bridge_mls_activated', time());
    
    // Flush rewrite rules
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'bridge_mls_activate');

/**
 * Plugin deactivation hook
 */
function bridge_mls_deactivate() {
    // Flush rewrite rules
    flush_rewrite_rules();
    
    // Clear all cached data
    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_bridge_mls_%'");
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_bridge_mls_%'");
}
register_deactivation_hook(__FILE__, 'bridge_mls_deactivate');

/**
 * Plugin uninstall hook
 */
function bridge_mls_uninstall() {
    global $wpdb;
    
    // Drop custom tables
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bridge_mls_properties");
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}bridge_mls_saved_searches");
    
    // Delete all options
    delete_option('bridge_mls_version');
    delete_option('bridge_mls_activated');
    
    // Clear all cached data
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_bridge_mls_%'");
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_bridge_mls_%'");
    
    // Clear any remaining plugin data
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'bridge_mls_%'");
}
register_uninstall_hook(__FILE__, 'bridge_mls_uninstall');

/**
 * Check plugin requirements
 */
function bridge_mls_check_requirements() {
    $requirements = array(
        'php_version' => '7.4',
        'wp_version' => '5.0',
        'extensions' => array('curl', 'json')
    );
    
    $errors = array();
    
    // Check PHP version
    if (version_compare(PHP_VERSION, $requirements['php_version'], '<')) {
        $errors[] = sprintf('PHP %s or higher is required. You are running %s.', 
            $requirements['php_version'], PHP_VERSION);
    }
    
    // Check WordPress version
    if (version_compare(get_bloginfo('version'), $requirements['wp_version'], '<')) {
        $errors[] = sprintf('WordPress %s or higher is required. You are running %s.', 
            $requirements['wp_version'], get_bloginfo('version'));
    }
    
    // Check extensions
    foreach ($requirements['extensions'] as $extension) {
        if (!extension_loaded($extension)) {
            $errors[] = sprintf('PHP extension "%s" is required but not loaded.', $extension);
        }
    }
    
    if (!empty($errors)) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(
            '<h1>Plugin Requirements Not Met</h1>' .
            '<p>The Bridge MLS Search plugin cannot be activated because:</p>' .
            '<ul><li>' . implode('</li><li>', $errors) . '</li></ul>' .
            '<p><a href="' . admin_url('plugins.php') . '">Return to Plugins</a></p>'
        );
    }
}
add_action('admin_init', 'bridge_mls_check_requirements');

/**
 * Add action links to plugin page
 */
function bridge_mls_action_links($links) {
    $debug_link = '<a href="' . admin_url('tools.php?page=bridge-mls-debug') . '">Debug</a>';
    array_unshift($links, $debug_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'bridge_mls_action_links');

/**
 * Add settings link to plugin page
 */
function bridge_mls_meta_links($links, $file) {
    if ($file == plugin_basename(__FILE__)) {
        $links[] = '<a href="' . admin_url('tools.php?page=bridge-mls-debug') . '">API Debug</a>';
        $links[] = '<a href="https://bridgedataoutput.com/docs/" target="_blank">Documentation</a>';
    }
    return $links;
}
add_filter('plugin_row_meta', 'bridge_mls_meta_links', 10, 2);

/**
 * Add custom cron schedules
 */
function bridge_mls_cron_schedules($schedules) {
    $schedules['bridge_mls_hourly'] = array(
        'interval' => 3600,
        'display' => 'Once Hourly (Bridge MLS)'
    );
    return $schedules;
}
add_filter('cron_schedules', 'bridge_mls_cron_schedules');

/**
 * Schedule cache cleanup
 */
function bridge_mls_schedule_cleanup() {
    if (!wp_next_scheduled('bridge_mls_cleanup')) {
        wp_schedule_event(time(), 'bridge_mls_hourly', 'bridge_mls_cleanup');
    }
}
add_action('wp', 'bridge_mls_schedule_cleanup');

/**
 * Cache cleanup function
 */
function bridge_mls_cleanup_cache() {
    global $wpdb;
    
    // Delete expired transients
    $wpdb->query("
        DELETE FROM {$wpdb->options} 
        WHERE option_name LIKE '_transient_timeout_bridge_mls_%' 
        AND option_value < UNIX_TIMESTAMP()
    ");
    
    // Clean up orphaned transients
    $wpdb->query("
        DELETE t1 FROM {$wpdb->options} t1
        LEFT JOIN {$wpdb->options} t2 ON t1.option_name = REPLACE(t2.option_name, '_transient_timeout_', '_transient_')
        WHERE t1.option_name LIKE '_transient_bridge_mls_%' 
        AND t2.option_name IS NULL
    ");
}
add_action('bridge_mls_cleanup', 'bridge_mls_cleanup_cache');

/**
 * Debug functions for development
 */
if (defined('WP_DEBUG') && WP_DEBUG) {
    
    /**
     * Quick test function for developers
     */
    function bridge_mls_quick_test() {
        if (!class_exists('BridgeAPI')) {
            return 'BridgeAPI class not loaded';
        }
        
        $api = new BridgeAPI();
        return $api->test_connection();
    }
    
    /**
     * Add debug info to admin footer
     */
    function bridge_mls_debug_info() {
        if (current_user_can('manage_options') && is_admin()) {
            echo '<!-- Bridge MLS Debug: Plugin Version ' . BRIDGE_MLS_VERSION . ' -->';
        }
    }
    add_action('admin_footer', 'bridge_mls_debug_info');
}