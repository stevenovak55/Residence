<?php
/**
 * Results Display Class - Fixed with Proper Media Support
 */

if (!defined('ABSPATH')) {
    exit;
}

class ResultsDisplay {
    
    private $api;
    
    public function __construct() {
        $this->api = new BridgeAPI();
    }
    
    /**
     * Render the search results
     */
    public function render($atts = array()) {
        $defaults = array(
            'per_page' => 25,
            'view_type' => 'grid',
            'show_map' => true,
            'show_filters' => true
        );
        
        $atts = wp_parse_args($atts, $defaults);
        
        // Get search parameters from URL
        $filters = $this->get_search_filters();
        $page = max(1, intval($_GET['page'] ?? 1));
        
        // Perform search
        $results = $this->api->search_properties($filters, $page, $atts['per_page']);
        
        if (isset($results['error'])) {
            return '<div class="bridge-mls-error">Error: ' . esc_html($results['error']) . '</div>';
        }
        
        ob_start();
        ?>
        
        <div id="bridge-mls-results" class="bridge-mls-container">
            
            <?php if ($atts['show_filters']): ?>
            <!-- Search Summary and Filters -->
            <div class="results-header">
                <?php $this->render_search_summary($results, $filters); ?>
                <?php $this->render_quick_filters($filters); ?>
            </div>
            <?php endif; ?>
            
            <!-- Results Controls -->
            <div class="results-controls">
                <div class="results-info">
                    <span class="results-count">
                        <?php printf('%s Results Found', number_format($results['total_count'])); ?>
                    </span>
                    
                    <?php if ($results['total_count'] > 0): ?>
                    <span class="results-range">
                        Showing <?php echo (($page - 1) * $atts['per_page']) + 1; ?> - 
                        <?php echo min($page * $atts['per_page'], $results['total_count']); ?>
                    </span>
                    <?php endif; ?>
                </div>
                
                <div class="results-actions">
                    <div class="view-toggle">
                        <button type="button" class="btn-view <?php echo $atts['view_type'] === 'grid' ? 'active' : ''; ?>" 
                                data-view="grid">Grid</button>
                        <button type="button" class="btn-view <?php echo $atts['view_type'] === 'list' ? 'active' : ''; ?>" 
                                data-view="list">List</button>
                    </div>
                    
                    <div class="sort-options">
                        <select id="sort_by" name="sort_by" class="form-control">
                            <option value="price_desc" <?php selected($_GET['sort_by'] ?? '', 'price_desc'); ?>>Price: High to Low</option>
                            <option value="price_asc" <?php selected($_GET['sort_by'] ?? '', 'price_asc'); ?>>Price: Low to High</option>
                            <option value="newest" <?php selected($_GET['sort_by'] ?? '', 'newest'); ?>>Newest Listings</option>
                            <option value="beds_desc" <?php selected($_GET['sort_by'] ?? '', 'beds_desc'); ?>>Bedrooms: High to Low</option>
                            <option value="sqft_desc" <?php selected($_GET['sort_by'] ?? '', 'sqft_desc'); ?>>Square Feet: High to Low</option>
                        </select>
                    </div>
                    
                    <div class="per-page-options">
                        <select id="per_page" name="per_page" class="form-control">
                            <option value="10" <?php selected($atts['per_page'], 10); ?>>10 per page</option>
                            <option value="25" <?php selected($atts['per_page'], 25); ?>>25 per page</option>
                            <option value="50" <?php selected($atts['per_page'], 50); ?>>50 per page</option>
                            <option value="100" <?php selected($atts['per_page'], 100); ?>>100 per page</option>
                        </select>
                    </div>
                    
                    <?php if ($atts['show_map']): ?>
                    <button type="button" class="btn btn-secondary btn-toggle-map">
                        <i class="icon-map"></i> Toggle Map
                    </button>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php if ($atts['show_map']): ?>
            <!-- Map Container -->
            <div id="results-map-container" class="results-map-container" style="display: none;">
                <div id="results-map" class="results-map"></div>
            </div>
            <?php endif; ?>
            
            <!-- Results Grid/List -->
            <div class="results-container <?php echo esc_attr($atts['view_type']); ?>-view">
                <?php if (empty($results['properties'])): ?>
                    <div class="no-results">
                        <h3>No Properties Found</h3>
                        <p>Try adjusting your search criteria to see more results.</p>
                        <a href="<?php echo home_url('/mls-search/'); ?>" class="btn btn-primary">New Search</a>
                    </div>
                <?php else: ?>
                    <div class="properties-grid">
                        <?php foreach ($results['properties'] as $property): ?>
                            <?php $this->render_property_card($property, $atts['view_type']); ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Pagination -->
            <?php if ($results['total_pages'] > 1): ?>
            <div class="results-pagination">
                <?php $this->render_pagination($results, $page); ?>
            </div>
            <?php endif; ?>
            
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // View toggle
            $('.btn-view').click(function() {
                var viewType = $(this).data('view');
                $('.btn-view').removeClass('active');
                $(this).addClass('active');
                $('.results-container').removeClass('grid-view list-view').addClass(viewType + '-view');
            });
            
            // Sort and pagination
            $('#sort_by, #per_page').change(function() {
                var currentUrl = new URL(window.location);
                currentUrl.searchParams.set($(this).attr('name'), $(this).val());
                if ($(this).attr('name') === 'per_page') {
                    currentUrl.searchParams.set('page', '1');
                }
                window.location.href = currentUrl.toString();
            });
            
            // Toggle map
            $('.btn-toggle-map').click(function() {
                $('#results-map-container').slideToggle();
                if ($('#results-map-container').is(':visible')) {
                    initializeMap();
                }
            });
            
            // Save property functionality
            $('.btn-save-property').click(function(e) {
                e.preventDefault();
                var listingKey = $(this).data('listing-key');
                // Implement save functionality
            });
        });
        
        function initializeMap() {
            // Map initialization would go here
        }
        </script>
        <?php
        
        return ob_get_clean();
    }
    
    /**
     * Render search summary
     */
    private function render_search_summary($results, $filters) {
        ?>
        <div class="search-summary">
            <h2>Property Search Results</h2>
            <?php if (!empty($filters)): ?>
            <div class="active-filters">
                <?php
                if (!empty($filters['cities'])) {
                    echo '<span class="filter-tag">Cities: ' . implode(', ', $filters['cities']) . '</span>';
                }
                if (!empty($filters['min_price']) || !empty($filters['max_price'])) {
                    $price_range = 'Price: ';
                    if (!empty($filters['min_price'])) {
                        $price_range .= '$' . number_format($filters['min_price']);
                    }
                    $price_range .= ' - ';
                    if (!empty($filters['max_price'])) {
                        $price_range .= '$' . number_format($filters['max_price']);
                    }
                    echo '<span class="filter-tag">' . $price_range . '</span>';
                }
                if (!empty($filters['bedrooms'])) {
                    echo '<span class="filter-tag">Bedrooms: ' . $filters['bedrooms'] . '+</span>';
                }
                if (!empty($filters['property_types'])) {
                    echo '<span class="filter-tag">Type: ' . implode(', ', $filters['property_types']) . '</span>';
                }
                ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render quick filters
     */
    private function render_quick_filters($filters) {
        ?>
        <div class="quick-filters">
            <span class="quick-filters-label">Quick Filters:</span>
            
            <div class="filter-group">
                <label>Price Range:</label>
                <select class="quick-filter" data-filter="price_range">
                    <option value="">Any Price</option>
                    <option value="0-300000">Under $300K</option>
                    <option value="300000-500000">$300K - $500K</option>
                    <option value="500000-750000">$500K - $750K</option>
                    <option value="750000-1000000">$750K - $1M</option>
                    <option value="1000000-">Over $1M</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label>Bedrooms:</label>
                <select class="quick-filter" data-filter="bedrooms">
                    <option value="">Any</option>
                    <option value="1">1+</option>
                    <option value="2">2+</option>
                    <option value="3">3+</option>
                    <option value="4">4+</option>
                    <option value="5">5+</option>
                </select>
            </div>
            
            <div class="filter-group">
                <label>Property Type:</label>
                <select class="quick-filter" data-filter="property_type">
                    <option value="">Any Type</option>
                    <option value="RES">Single Family</option>
                    <option value="CND">Condo</option>
                    <option value="MUL">Multi Family</option>
                    <option value="LND">Land</option>
                    <option value="COM">Commercial</option>
                </select>
            </div>
            
            <button type="button" class="btn btn-link btn-clear-filters">Clear All Filters</button>
        </div>
        <?php
    }
    
    /**
     * Render individual property card
     */
    public function render_property_card($property, $view_type = 'grid') {
        $listing_key = $property['ListingKey'] ?? '';
        $price = $property['ListPrice'] ?? 0;
        $bedrooms = $property['BedroomsTotal'] ?? 'N/A';
        $bathrooms = $property['BathroomsTotalInteger'] ?? 'N/A';
        $sqft = $property['LivingArea'] ?? 'N/A';
        $address = $this->format_address($property);
        $status = $property['StandardStatus'] ?? '';
        $photos_count = $property['PhotosCount'] ?? 0;
        
        // Get first photo URL from media array
        $photo_url = $this->get_first_photo_url($property);
        
        ?>
        <div class="property-card <?php echo esc_attr($view_type); ?>" data-listing-key="<?php echo esc_attr($listing_key); ?>">
            <div class="property-image">
                <?php if ($photo_url): ?>
                    <img src="<?php echo esc_url($photo_url); ?>" alt="<?php echo esc_attr($address); ?>" loading="lazy">
                <?php else: ?>
                    <div class="no-image">No Image Available</div>
                <?php endif; ?>
                
                <div class="property-badges">
                    <?php if ($status === 'ActiveUnderContract'): ?>
                        <span class="badge under-contract">Under Contract</span>
                    <?php elseif ($status === 'Sold'): ?>
                        <span class="badge sold">Sold</span>
                    <?php elseif ($photos_count > 0): ?>
                        <span class="badge photos"><?php echo $photos_count; ?> Photos</span>
                    <?php endif; ?>
                </div>
                
                <div class="property-actions">
                    <button type="button" class="btn-action btn-save-property" data-listing-key="<?php echo esc_attr($listing_key); ?>">
                        <i class="icon-heart"></i>
                    </button>
                    <button type="button" class="btn-action btn-share-property" data-listing-key="<?php echo esc_attr($listing_key); ?>">
                        <i class="icon-share"></i>
                    </button>
                </div>
            </div>
            
            <div class="property-details">
                <div class="property-price">
                    $<?php echo number_format($price); ?>
                    <?php if (!empty($property['PricePerSquareFoot'])): ?>
                        <span class="price-per-sqft">$<?php echo number_format($property['PricePerSquareFoot']); ?>/sq ft</span>
                    <?php endif; ?>
                </div>
                
                <div class="property-specs">
                    <span class="spec bedrooms"><?php echo $bedrooms; ?> bed</span>
                    <span class="spec bathrooms"><?php echo $bathrooms; ?> bath</span>
                    <?php if ($sqft !== 'N/A'): ?>
                        <span class="spec sqft"><?php echo number_format($sqft); ?> sq ft</span>
                    <?php endif; ?>
                    <?php if (!empty($property['LotSizeAcres'])): ?>
                        <span class="spec lot"><?php echo number_format($property['LotSizeAcres'], 2); ?> acres</span>
                    <?php endif; ?>
                </div>
                
                <div class="property-address">
                    <a href="<?php echo $this->get_property_url($listing_key); ?>" class="property-link">
                        <?php echo esc_html($address); ?>
                    </a>
                </div>
                
                <?php if ($view_type === 'list'): ?>
                <div class="property-description">
                    <?php 
                    $description = $property['PublicRemarks'] ?? '';
                    if ($description) {
                        echo '<p>' . esc_html(wp_trim_words($description, 30)) . '</p>';
                    }
                    ?>
                </div>
                <?php endif; ?>
                
                <div class="property-meta">
                    <div class="property-info">
                        <?php if (!empty($property['PropertyType'])): ?>
                            <span class="property-type"><?php echo esc_html($property['PropertyType']); ?></span>
                        <?php endif; ?>
                        
                        <?php if (!empty($property['YearBuilt'])): ?>
                            <span class="year-built">Built <?php echo $property['YearBuilt']; ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="property-listing-info">
                        <?php if (!empty($property['ListingId'])): ?>
                            <span class="mls-number">MLS# <?php echo esc_html($property['ListingId']); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Get first photo URL from property media array
     */
    private function get_first_photo_url($property) {
        // Check if media array exists and has items
        if (!empty($property['media']) && is_array($property['media'])) {
            foreach ($property['media'] as $media_item) {
                if (!empty($media_item['MediaURL'])) {
                    // Validate the URL
                    if (filter_var($media_item['MediaURL'], FILTER_VALIDATE_URL)) {
                        return $media_item['MediaURL'];
                    }
                }
            }
        }
        
        // Return null if no valid photo found - the template will show "No Image Available"
        return null;
    }
    
    /**
     * Render pagination
     */
    private function render_pagination($results, $current_page) {
        $total_pages = $results['total_pages'];
        $base_url = $this->get_base_search_url();
        
        if ($total_pages <= 1) {
            return;
        }
        
        ?>
        <nav class="pagination-nav" aria-label="Search results pagination">
            <ul class="pagination">
                
                <?php if ($current_page > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo esc_url($base_url . '&page=' . ($current_page - 1)); ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php
                $start_page = max(1, $current_page - 2);
                $end_page = min($total_pages, $current_page + 2);
                
                if ($start_page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo esc_url($base_url . '&page=1'); ?>">1</a>
                    </li>
                    <?php if ($start_page > 2): ?>
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                <li class="page-item <?php echo $i === $current_page ? 'active' : ''; ?>">
                    <a class="page-link" href="<?php echo esc_url($base_url . '&page=' . $i); ?>"><?php echo $i; ?></a>
                </li>
                <?php endfor; ?>
                
                <?php if ($end_page < $total_pages): ?>
                    <?php if ($end_page < $total_pages - 1): ?>
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                    <?php endif; ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo esc_url($base_url . '&page=' . $total_pages); ?>"><?php echo $total_pages; ?></a>
                    </li>
                <?php endif; ?>
                
                <?php if ($current_page < $total_pages): ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo esc_url($base_url . '&page=' . ($current_page + 1)); ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
                <?php endif; ?>
                
            </ul>
        </nav>
        <?php
    }
    
    /**
     * Format property address
     */
    private function format_address($property) {
        $parts = array();
        
        if (!empty($property['StreetNumber'])) {
            $parts[] = $property['StreetNumber'];
        }
        
        if (!empty($property['StreetName'])) {
            $parts[] = $property['StreetName'];
        }
        
        if (!empty($property['UnitNumber'])) {
            $parts[] = 'Unit ' . $property['UnitNumber'];
        }
        
        $address = implode(' ', $parts);
        
        if (!empty($property['City'])) {
            $address .= ', ' . $property['City'];
        }
        
        if (!empty($property['StateOrProvince'])) {
            $address .= ', ' . $property['StateOrProvince'];
        }
        
        if (!empty($property['PostalCode'])) {
            $address .= ' ' . $property['PostalCode'];
        }
        
        return $address;
    }
    
    /**
     * Get property detail page URL
     */
    private function get_property_url($listing_key) {
        return home_url('/mls-property/' . $listing_key . '/');
    }
    
    /**
     * Get base search URL with current parameters
     */
    private function get_base_search_url() {
        $params = $_GET;
        unset($params['page']); // Remove page parameter
        
        $query_string = http_build_query($params);
        return home_url('/mls-search/') . ($query_string ? '?' . $query_string : '');
    }
    
    /**
     * Get search filters from URL parameters
     */
    private function get_search_filters() {
        $filters = array();
        
        // Property types
        if (!empty($_GET['property_types'])) {
            $filters['property_types'] = array_map('sanitize_text_field', (array)$_GET['property_types']);
        }
        
        // Status
        if (!empty($_GET['status'])) {
            $filters['status'] = array_map('sanitize_text_field', (array)$_GET['status']);
        }
        
        // Price range
        if (!empty($_GET['min_price'])) {
            $filters['min_price'] = intval($_GET['min_price']);
        }
        if (!empty($_GET['max_price'])) {
            $filters['max_price'] = intval($_GET['max_price']);
        }
        
        // Bedrooms, bathrooms, etc.
        $numeric_filters = array('bedrooms', 'bathrooms', 'rooms', 'garage_spaces', 'parking_spaces', 'year_built');
        foreach ($numeric_filters as $filter) {
            if (!empty($_GET[$filter])) {
                $filters[$filter] = intval($_GET[$filter]);
            }
        }
        
        // Cities
        if (!empty($_GET['cities'])) {
            $filters['cities'] = array_map('sanitize_text_field', (array)$_GET['cities']);
        }
        
        // Keywords
        if (!empty($_GET['keywords'])) {
            $filters['keywords'] = sanitize_text_field($_GET['keywords']);
        }
        
        // Address search
        if (!empty($_GET['street_name'])) {
            $filters['street_address'] = sanitize_text_field($_GET['street_name']);
        }
        
        if (!empty($_GET['zip_code'])) {
            $filters['zip_code'] = sanitize_text_field($_GET['zip_code']);
        }
        
        return $filters;
    }
}