<?php
/**
 * Search Form Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class SearchForm {
    
    public function __construct() {
        // Constructor
    }
    
    /**
     * Render the search form
     */
    public function render($atts = array()) {
        $defaults = array(
            'show_map' => false,
            'show_additional_criteria' => true,
            'redirect_url' => home_url('/mls-search/')
        );
        
        $atts = wp_parse_args($atts, $defaults);
        
        ob_start();
        
        // Get current search parameters from URL
        $current_filters = $this->get_current_filters();
        
        ?>
        <div id="bridge-mls-search-form" class="bridge-mls-container">
            <form id="mls-search-form" method="GET" action="<?php echo esc_url($atts['redirect_url']); ?>">
                
                <!-- List Numbers -->
                <div class="search-section">
                    <label for="list_numbers" class="section-label">LIST NUMBER(S)</label>
                    <input type="text" id="list_numbers" name="list_numbers" 
                           value="<?php echo esc_attr($current_filters['list_numbers'] ?? ''); ?>" 
                           placeholder="Enter MLS numbers separated by commas" class="form-control">
                </div>
                
                <div class="search-row">
                    <!-- Property Type Section -->
                    <div class="search-column property-type-section">
                        <div class="section-header">
                            <label class="section-label">PROPERTY TYPE</label>
                            <span class="toggle-icon">▼</span>
                        </div>
                        <div class="section-content">
                            <?php $this->render_property_types($current_filters); ?>
                        </div>
                    </div>
                    
                    <!-- Status Section -->
                    <div class="search-column status-section">
                        <div class="section-header">
                            <label class="section-label">STATUS</label>
                            <span class="toggle-icon">▼</span>
                        </div>
                        <div class="section-content">
                            <?php $this->render_status_options($current_filters); ?>
                            
                            <!-- List Date and Off-Market Timeframe -->
                            <div class="status-additional">
                                <div class="form-group">
                                    <label for="list_date">List Date</label>
                                    <input type="date" id="list_date" name="list_date" 
                                           value="<?php echo esc_attr($current_filters['list_date'] ?? ''); ?>" 
                                           class="form-control">
                                </div>
                                
                                <div class="form-group">
                                    <label for="off_market_timeframe">Off-Market Timeframe</label>
                                    <select id="off_market_timeframe" name="off_market_timeframe" class="form-control">
                                        <option value="">Select timeframe</option>
                                        <option value="30" <?php selected($current_filters['off_market_timeframe'] ?? '', '30'); ?>>TODAY - 1 MONTH</option>
                                        <option value="90" <?php selected($current_filters['off_market_timeframe'] ?? '', '90'); ?>>TODAY - 3 MONTHS</option>
                                        <option value="180" <?php selected($current_filters['off_market_timeframe'] ?? '', '180'); ?>>TODAY - 6 MONTHS</option>
                                        <option value="365" <?php selected($current_filters['off_market_timeframe'] ?? '', '365'); ?>>TODAY - 12 MONTHS</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Standard Search Criteria -->
                    <div class="search-column criteria-section">
                        <div class="section-header">
                            <label class="section-label">STANDARD SEARCH CRITERIA</label>
                            <span class="toggle-icon">▼</span>
                        </div>
                        <div class="section-content">
                            <?php $this->render_standard_criteria($current_filters); ?>
                        </div>
                    </div>
                </div>
                
                <!-- Price Section -->
                <div class="search-section price-section">
                    <div class="section-header">
                        <label class="section-label">PRICE</label>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="section-content">
                        <div class="price-range">
                            <div class="form-group">
                                <label for="min_price">Low</label>
                                <input type="number" id="min_price" name="min_price" 
                                       value="<?php echo esc_attr($current_filters['min_price'] ?? ''); ?>" 
                                       placeholder="Min Price" class="form-control" step="1000">
                            </div>
                            <div class="form-group">
                                <label for="max_price">High</label>
                                <input type="number" id="max_price" name="max_price" 
                                       value="<?php echo esc_attr($current_filters['max_price'] ?? ''); ?>" 
                                       placeholder="Max Price" class="form-control" step="1000">
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Address Section -->
                <div class="search-section address-section">
                    <div class="section-header">
                        <label class="section-label">ADDRESS</label>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="section-content">
                        <?php $this->render_address_search($current_filters); ?>
                    </div>
                </div>
                
                <!-- Towns Section -->
                <div class="search-section towns-section">
                    <div class="section-header">
                        <label class="section-label">TOWNS</label>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="section-content">
                        <?php $this->render_towns_search($current_filters); ?>
                    </div>
                </div>
                
                <!-- Listing Events Section -->
                <div class="search-section listing-events-section">
                    <div class="section-header">
                        <label class="section-label">LISTING EVENTS</label>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="section-content">
                        <?php $this->render_listing_events($current_filters); ?>
                    </div>
                </div>
                
                <!-- Keywords Section -->
                <div class="search-section keywords-section">
                    <div class="section-header">
                        <label class="section-label">KEYWORDS (Public Remarks only)</label>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="section-content">
                        <?php $this->render_keywords_search($current_filters); ?>
                    </div>
                </div>
                
                <?php if ($atts['show_additional_criteria']): ?>
                <!-- Additional Criteria Section -->
                <div class="search-section additional-criteria-section">
                    <div class="section-header">
                        <label class="section-label">ADDITIONAL CRITERIA</label>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="section-content">
                        <!-- Additional criteria would go here -->
                        <p>Additional search filters can be added here</p>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Search Actions -->
                <div class="search-actions">
                    <button type="submit" class="btn btn-primary btn-search">
                        <i class="icon-search"></i> View Results
                    </button>
                    <button type="button" class="btn btn-secondary btn-save">
                        <i class="icon-save"></i> Save
                    </button>
                    <button type="button" class="btn btn-secondary btn-load">
                        <i class="icon-load"></i> Load
                    </button>
                    <button type="button" class="btn btn-secondary btn-attach">
                        <i class="icon-attach"></i> Attach
                    </button>
                    <button type="button" class="btn btn-secondary btn-download">
                        <i class="icon-download"></i> Download
                    </button>
                    <button type="button" class="btn btn-secondary btn-stats">
                        <i class="icon-stats"></i> Stats
                    </button>
                    <button type="reset" class="btn btn-secondary btn-clear">
                        <i class="icon-clear"></i> Clear
                    </button>
                    <button type="button" class="btn btn-secondary btn-map">
                        <i class="icon-map"></i> Map
                    </button>
                    <button type="button" class="btn btn-secondary btn-recent">
                        <i class="icon-recent"></i> Recent
                    </button>
                </div>
                
            </form>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Toggle section visibility
            $('.section-header').click(function() {
                $(this).next('.section-content').slideToggle();
                $(this).find('.toggle-icon').text(function(i, text) {
                    return text === '▼' ? '▲' : '▼';
                });
            });
            
            // Load towns dynamically
            $('#coverage_area').change(function() {
                var state = $('#state').val();
                var coverageArea = $(this).val();
                
                if (state && coverageArea) {
                    $.ajax({
                        url: bridge_mls_ajax.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'mls_get_towns',
                            nonce: bridge_mls_ajax.nonce,
                            state: state,
                            coverage_area: coverageArea
                        },
                        success: function(response) {
                            if (response.success) {
                                var townsList = $('#towns-list');
                                townsList.empty();
                                
                                $.each(response.data, function(index, town) {
                                    townsList.append(
                                        '<label class="checkbox-item">' +
                                        '<input type="checkbox" name="cities[]" value="' + town + '"> ' +
                                        town +
                                        '</label>'
                                    );
                                });
                            }
                        }
                    });
                }
            });
        });
        </script>
        <?php
        
        return ob_get_clean();
    }
    
    /**
     * Render property type checkboxes
     */
    private function render_property_types($current_filters) {
        $property_types = array(
            'Residential' => array(
                'Single Family (SF)' => 'RES',
                'Condominium (CC)' => 'CND', 
                'Multi Family (MF)' => 'MUL'
            ),
            'Land' => array(
                'Land (LD)' => 'LND'
            ),
            'Commercial' => array(
                'Commercial (CI)' => 'COM',
                'Business Opp. (BU)' => 'BUS'
            ),
            'Other' => array(
                'Residential Rental (RN)' => 'RNT',
                'Mobile Home (MH)' => 'MFH'
            )
        );
        
        $selected_types = $current_filters['property_types'] ?? array();
        
        echo '<div class="property-types">';
        echo '<label class="checkbox-item select-all">';
        echo '<input type="checkbox" id="select_all_types"> Select All';
        echo '</label>';
        
        foreach ($property_types as $category => $types) {
            foreach ($types as $label => $value) {
                $checked = in_array($value, $selected_types) ? 'checked' : '';
                echo '<label class="checkbox-item">';
                echo '<input type="checkbox" name="property_types[]" value="' . esc_attr($value) . '" ' . $checked . '> ';
                echo esc_html($label);
                echo '</label>';
            }
        }
        echo '</div>';
    }
    
    /**
     * Render status options
     */
    private function render_status_options($current_filters) {
        $statuses = array(
            'New (NEW)' => 'Active',
            'Active (ACT)' => 'Active',
            'Price Changed (PCG)' => 'Active',
            'Back on Market (BOM)' => 'Active',
            'Extended (EXT)' => 'Active',
            'Reactivated (RAC)' => 'Active',
            'Contingent (CTG)' => 'Pending',
            'Under Agreement (UAG)' => 'ActiveUnderContract',
            'Sold (SLD)' => 'Sold',
            'Rented (RNT)' => 'Sold',
            'Temporarily Withdrawn (WDN)' => 'Withdrawn',
            'Expired (EXP)' => 'Expired',
            'Canceled (CAN)' => 'Canceled',
            'Coming Soon (CSO)' => 'ComingSoon'
        );
        
        $selected_statuses = $current_filters['status'] ?? array();
        
        echo '<div class="status-options">';
        echo '<label class="checkbox-item select-all">';
        echo '<input type="checkbox" id="select_all_status"> Select All';
        echo '</label>';
        
        foreach ($statuses as $label => $value) {
            $checked = in_array($value, $selected_statuses) ? 'checked' : '';
            echo '<label class="checkbox-item">';
            echo '<input type="checkbox" name="status[]" value="' . esc_attr($value) . '" ' . $checked . '> ';
            echo esc_html($label);
            echo '</label>';
        }
        echo '</div>';
    }
    
    /**
     * Render standard search criteria
     */
    private function render_standard_criteria($current_filters) {
        ?>
        <div class="criteria-grid">
            <div class="criteria-row">
                <div class="form-group">
                    <label for="bedrooms">Bedrooms</label>
                    <select id="bedrooms" name="bedrooms" class="form-control">
                        <option value="">Any</option>
                        <?php for ($i = 1; $i <= 10; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php selected($current_filters['bedrooms'] ?? '', $i); ?>><?php echo $i; ?>+</option>
                        <?php endfor; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="bathrooms">Total Bathrooms</label>
                    <select id="bathrooms" name="bathrooms" class="form-control">
                        <option value="">Any</option>
                        <?php for ($i = 1; $i <= 10; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php selected($current_filters['bathrooms'] ?? '', $i); ?>><?php echo $i; ?>+</option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            
            <div class="criteria-row">
                <div class="form-group">
                    <label for="rooms">Rooms</label>
                    <select id="rooms" name="rooms" class="form-control">
                        <option value="">Any</option>
                        <?php for ($i = 1; $i <= 15; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php selected($current_filters['rooms'] ?? '', $i); ?>><?php echo $i; ?>+</option>
                        <?php endfor; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="acres">Acres</label>
                    <input type="number" id="acres" name="acres" step="0.1" 
                           value="<?php echo esc_attr($current_filters['acres'] ?? ''); ?>" 
                           placeholder="Min acres" class="form-control">
                </div>
            </div>
            
            <div class="criteria-row">
                <div class="form-group">
                    <label for="living_area">Living Area Total (SqFt)</label>
                    <input type="number" id="living_area" name="living_area" 
                           value="<?php echo esc_attr($current_filters['living_area'] ?? ''); ?>" 
                           placeholder="Min sq ft" class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="price_per_sqft">Price per SqFt</label>
                    <input type="number" id="price_per_sqft" name="price_per_sqft" 
                           value="<?php echo esc_attr($current_filters['price_per_sqft'] ?? ''); ?>" 
                           placeholder="Max price/sqft" class="form-control">
                </div>
            </div>
            
            <div class="criteria-row">
                <div class="form-group">
                    <label for="year_built">Year Built</label>
                    <input type="number" id="year_built" name="year_built" 
                           value="<?php echo esc_attr($current_filters['year_built'] ?? ''); ?>" 
                           placeholder="Min year" class="form-control" min="1800" max="<?php echo date('Y'); ?>">
                </div>
                
                <div class="form-group">
                    <label for="parking_spaces">Total Parking Spaces</label>
                    <select id="parking_spaces" name="parking_spaces" class="form-control">
                        <option value="">Any</option>
                        <?php for ($i = 1; $i <= 10; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php selected($current_filters['parking_spaces'] ?? '', $i); ?>><?php echo $i; ?>+</option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            
            <div class="criteria-row">
                <div class="form-group">
                    <label for="garage_spaces">Garage Spaces</label>
                    <select id="garage_spaces" name="garage_spaces" class="form-control">
                        <option value="">Any</option>
                        <?php for ($i = 1; $i <= 6; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php selected($current_filters['garage_spaces'] ?? '', $i); ?>><?php echo $i; ?>+</option>
                        <?php endfor; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="parking_non_garage">Parking Spaces (Non-Garage)</label>
                    <select id="parking_non_garage" name="parking_non_garage" class="form-control">
                        <option value="">Any</option>
                        <?php for ($i = 1; $i <= 10; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php selected($current_filters['parking_non_garage'] ?? '', $i); ?>><?php echo $i; ?>+</option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render address search section
     */
    private function render_address_search($current_filters) {
        ?>
        <div class="address-search">
            <div class="address-type">
                <label class="radio-item">
                    <input type="radio" name="address_type" value="street" <?php checked($current_filters['address_type'] ?? 'street', 'street'); ?>>
                    Street Address
                </label>
                <label class="radio-item">
                    <input type="radio" name="address_type" value="location" <?php checked($current_filters['address_type'] ?? '', 'location'); ?>>
                    My Location
                </label>
            </div>
            
            <div class="address-fields">
                <div class="form-group">
                    <label for="street_number">Street #</label>
                    <input type="text" id="street_number" name="street_number" 
                           value="<?php echo esc_attr($current_filters['street_number'] ?? ''); ?>" 
                           class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="street_name">Street Name</label>
                    <input type="text" id="street_name" name="street_name" 
                           value="<?php echo esc_attr($current_filters['street_name'] ?? ''); ?>" 
                           class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="zip_code">Zip Code</label>
                    <input type="text" id="zip_code" name="zip_code" 
                           value="<?php echo esc_attr($current_filters['zip_code'] ?? ''); ?>" 
                           class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="radius">Radius</label>
                    <select id="radius" name="radius" class="form-control">
                        <option value="">Select radius</option>
                        <option value="0.25" <?php selected($current_filters['radius'] ?? '', '0.25'); ?>>0.25 Miles</option>
                        <option value="0.5" <?php selected($current_filters['radius'] ?? '', '0.5'); ?>>0.5 Miles</option>
                        <option value="1" <?php selected($current_filters['radius'] ?? '', '1'); ?>>1 Mile</option>
                        <option value="2" <?php selected($current_filters['radius'] ?? '', '2'); ?>>2 Miles</option>
                        <option value="5" <?php selected($current_filters['radius'] ?? '', '5'); ?>>5 Miles</option>
                        <option value="10" <?php selected($current_filters['radius'] ?? '', '10'); ?>>10 Miles</option>
                    </select>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render towns search section
     */
    private function render_towns_search($current_filters) {
        ?>
        <div class="towns-search">
            <div class="towns-controls">
                <div class="form-group">
                    <label for="state">State</label>
                    <select id="state" name="state" class="form-control">
                        <option value="MA" <?php selected($current_filters['state'] ?? 'MA', 'MA'); ?>>MA</option>
                        <option value="NH" <?php selected($current_filters['state'] ?? '', 'NH'); ?>>NH</option>
                        <option value="RI" <?php selected($current_filters['state'] ?? '', 'RI'); ?>>RI</option>
                        <option value="CT" <?php selected($current_filters['state'] ?? '', 'CT'); ?>>CT</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="coverage_area">Coverage Areas</label>
                    <select id="coverage_area" name="coverage_area" class="form-control">
                        <option value="Eastern Mass" <?php selected($current_filters['coverage_area'] ?? 'Eastern Mass', 'Eastern Mass'); ?>>Eastern Mass</option>
                        <option value="Western Mass" <?php selected($current_filters['coverage_area'] ?? '', 'Western Mass'); ?>>Western Mass</option>
                        <option value="Central Mass" <?php selected($current_filters['coverage_area'] ?? '', 'Central Mass'); ?>>Central Mass</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="show_areas">Show Areas</label>
                    <div class="radio-group">
                        <label class="radio-item">
                            <input type="radio" name="show_areas" value="yes" <?php checked($current_filters['show_areas'] ?? 'yes', 'yes'); ?>>
                            Yes
                        </label>
                        <label class="radio-item">
                            <input type="radio" name="show_areas" value="no" <?php checked($current_filters['show_areas'] ?? '', 'no'); ?>>
                            No
                        </label>
                    </div>
                </div>
            </div>
            
            <div class="towns-selection">
                <div class="towns-header">
                    <span>Selected Towns</span>
                    <button type="button" class="btn btn-link btn-remove-all">Remove All</button>
                </div>
                
                <div class="towns-list-container">
                    <input type="text" placeholder="Type Full or Partial Name" class="towns-search-input">
                    <button type="button" class="btn btn-primary btn-add">Add</button>
                    
                    <div id="towns-list" class="towns-list">
                        <!-- Towns will be loaded dynamically -->
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render listing events section
     */
    private function render_listing_events($current_filters) {
        ?>
        <div class="listing-events">
            <div class="event-types">
                <label class="checkbox-item">
                    <input type="checkbox" name="listing_events[]" value="open_houses" 
                           <?php checked(in_array('open_houses', $current_filters['listing_events'] ?? array())); ?>>
                    🏠 Open Houses
                </label>
                <label class="checkbox-item">
                    <input type="checkbox" name="listing_events[]" value="broker_tours" 
                           <?php checked(in_array('broker_tours', $current_filters['listing_events'] ?? array())); ?>>
                    🏢 Broker Tours
                </label>
            </div>
            
            <div class="event-timeframe">
                <label for="event_timeframe">For:</label>
                <select id="event_timeframe" name="event_timeframe" class="form-control">
                    <option value="3" <?php selected($current_filters['event_timeframe'] ?? '3', '3'); ?>>Next 3 Days</option>
                    <option value="7" <?php selected($current_filters['event_timeframe'] ?? '', '7'); ?>>Next 7 Days</option>
                    <option value="14" <?php selected($current_filters['event_timeframe'] ?? '', '14'); ?>>Next 14 Days</option>
                    <option value="30" <?php selected($current_filters['event_timeframe'] ?? '', '30'); ?>>Next 30 Days</option>
                </select>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render keywords search section
     */
    private function render_keywords_search($current_filters) {
        ?>
        <div class="keywords-search">
            <div class="keyword-options">
                <label class="radio-item">
                    <input type="radio" name="keyword_mode" value="any" <?php checked($current_filters['keyword_mode'] ?? 'any', 'any'); ?>>
                    🔍 Any
                </label>
                <label class="radio-item">
                    <input type="radio" name="keyword_mode" value="all" <?php checked($current_filters['keyword_mode'] ?? '', 'all'); ?>>
                    📝 All
                </label>
                <label class="radio-item">
                    <input type="radio" name="keyword_mode" value="include" <?php checked($current_filters['keyword_mode'] ?? '', 'include'); ?>>
                    ✅ Include
                </label>
                <label class="radio-item">
                    <input type="radio" name="keyword_mode" value="exclude" <?php checked($current_filters['keyword_mode'] ?? '', 'exclude'); ?>>
                    ❌ Exclude
                </label>
            </div>
            
            <div class="keyword-input">
                <textarea name="keywords" placeholder="Enter keywords to search in property descriptions..." 
                          class="form-control" rows="3"><?php echo esc_textarea($current_filters['keywords'] ?? ''); ?></textarea>
            </div>
        </div>
        <?php
    }
    
    /**
     * Get current filters from URL parameters
     */
    private function get_current_filters() {
        $filters = array();
        
        // Get all GET parameters and sanitize them
        foreach ($_GET as $key => $value) {
            if (is_array($value)) {
                $filters[$key] = array_map('sanitize_text_field', $value);
            } else {
                $filters[$key] = sanitize_text_field($value);
            }
        }
        
        return $filters;
    }
}