<?php
/**
 * Admin Debug Class for Bridge MLS Plugin - Complete Fixed Version
 */

if (!defined('ABSPATH')) {
    exit;
}

class BridgeMLSAdminDebug {
    
    private $api;
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'handle_admin_actions'));
        add_action('wp_ajax_bridge_test_api', array($this, 'ajax_test_api'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_submenu_page(
            'tools.php',
            'Bridge MLS Debug',
            'Bridge MLS Debug',
            'manage_options',
            'bridge-mls-debug',
            array($this, 'debug_page')
        );
    }
    
    /**
     * Handle admin actions
     */
    public function handle_admin_actions() {
        if (!isset($_POST['bridge_debug_action']) || !current_user_can('manage_options')) {
            return;
        }
        
        if (!wp_verify_nonce($_POST['bridge_debug_nonce'], 'bridge_debug_action')) {
            wp_die('Security check failed');
        }
        
        $this->api = new BridgeAPI();
        
        switch ($_POST['bridge_debug_action']) {
            case 'test_connection':
                $this->test_connection();
                break;
            case 'test_simple_search':
                $this->test_simple_search();
                break;
            case 'test_filtered_search':
                $this->test_filtered_search();
                break;
            case 'test_available_fields':
                $this->test_available_fields();
                break;
            case 'clear_cache':
                $this->clear_cache();
                break;
        }
    }
    
    /**
     * Debug admin page
     */
    public function debug_page() {
        ?>
        <div class="wrap">
            <h1>Bridge MLS Debug</h1>
            
            <div class="notice notice-info">
                <p><strong>Use this page to test your Bridge API connection and troubleshoot issues.</strong></p>
            </div>
            
            <!-- Test Results -->
            <?php $this->display_test_results(); ?>
            
            <!-- Test Actions -->
            <div class="card">
                <h2>API Tests</h2>
                <p>Run these tests in order to diagnose connection issues:</p>
                
                <form method="post">
                    <?php wp_nonce_field('bridge_debug_action', 'bridge_debug_nonce'); ?>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">1. Test Connection</th>
                            <td>
                                <button type="submit" name="bridge_debug_action" value="test_connection" class="button button-primary">
                                    Test API Connection
                                </button>
                                <p class="description">Tests basic connectivity to the Bridge API metadata endpoint</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">2. Test Simple Search</th>
                            <td>
                                <button type="submit" name="bridge_debug_action" value="test_simple_search" class="button button-primary">
                                    Test Simple Search
                                </button>
                                <p class="description">Tests property search without any filters (first 5 properties)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">3. Test Filtered Search</th>
                            <td>
                                <button type="submit" name="bridge_debug_action" value="test_filtered_search" class="button button-primary">
                                    Test Filtered Search
                                </button>
                                <p class="description">Tests property search with basic filters (Active listings over $100k)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">4. Test Available Fields</th>
                            <td>
                                <button type="submit" name="bridge_debug_action" value="test_available_fields" class="button button-primary">
                                    Test Available Fields
                                </button>
                                <p class="description">Discovers what fields are available in your MLS dataset</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Clear Cache</th>
                            <td>
                                <button type="submit" name="bridge_debug_action" value="clear_cache" class="button button-secondary">
                                    Clear All Cache
                                </button>
                                <p class="description">Clears all cached API responses</p>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
            
            <!-- Configuration Info -->
            <div class="card">
                <h2>Current Configuration</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">Base URL</th>
                        <td><code>https://api.bridgedataoutput.com/api/v2/OData/shared_mlspin_41854c5/</code></td>
                    </tr>
                    <tr>
                        <th scope="row">Access Token</th>
                        <td><code>1c69fed3083478d187d4ce8deb8788ed</code></td>
                    </tr>
                    <tr>
                        <th scope="row">Plugin Version</th>
                        <td><?php echo defined('BRIDGE_MLS_VERSION') ? BRIDGE_MLS_VERSION : '1.0.0'; ?></td>
                    </tr>
                </table>
            </div>
            
            <!-- Troubleshooting Guide -->
            <div class="card">
                <h2>Troubleshooting Guide</h2>
                <h3>Common Error Codes</h3>
                <ul>
                    <li><strong>HTTP 400 (Bad Request):</strong> Invalid OData query syntax or unsupported field names</li>
                    <li><strong>HTTP 401 (Unauthorized):</strong> Invalid access token - check your credentials</li>
                    <li><strong>HTTP 403 (Forbidden):</strong> Access denied - token may not have proper permissions</li>
                    <li><strong>HTTP 404 (Not Found):</strong> Invalid endpoint URL - verify the base URL</li>
                    <li><strong>HTTP 429 (Rate Limited):</strong> Too many requests - wait before retrying</li>
                    <li><strong>HTTP 500 (Server Error):</strong> Bridge API server issue - try again later</li>
                </ul>
                
                <h3>Field Errors</h3>
                <ul>
                    <li><strong>"Cannot select field":</strong> The field doesn't exist in your MLS dataset</li>
                    <li><strong>"Invalid property name":</strong> Field name is misspelled or not available</li>
                    <li><strong>Use "Test Available Fields"</strong> to see what fields are actually available</li>
                </ul>
                
                <h3>If Tests Fail</h3>
                <ol>
                    <li><strong>Check Error Logs:</strong> Look in your WordPress error logs for detailed error messages</li>
                    <li><strong>Verify Credentials:</strong> Ensure your access token is correct and active</li>
                    <li><strong>Check Firewall:</strong> Make sure your server can make outbound HTTPS requests</li>
                    <li><strong>Contact Bridge Support:</strong> If all tests fail, contact Bridge Data Output support</li>
                </ol>
            </div>
            
            <!-- System Info -->
            <div class="card">
                <h2>System Information</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">WordPress Version</th>
                        <td><?php echo get_bloginfo('version'); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">PHP Version</th>
                        <td><?php echo PHP_VERSION; ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Plugin Active</th>
                        <td><?php echo is_plugin_active('bridge-mls-search/bridge-mls-search.php') ? '✅ Yes' : '❌ No'; ?></td>
                    </tr>
                    <tr>
                        <th scope="row">cURL Enabled</th>
                        <td><?php echo function_exists('curl_version') ? '✅ Yes' : '❌ No'; ?></td>
                    </tr>
                    <tr>
                        <th scope="row">OpenSSL</th>
                        <td><?php echo extension_loaded('openssl') ? '✅ Enabled' : '❌ Disabled'; ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Max Execution Time</th>
                        <td><?php echo ini_get('max_execution_time'); ?> seconds</td>
                    </tr>
                </table>
            </div>
            
            <!-- Quick URL Test -->
            <div class="card">
                <h2>Quick URL Test</h2>
                <p>Test this URL directly in your browser (you should see JSON data):</p>
                <p><a href="https://api.bridgedataoutput.com/api/v2/OData/shared_mlspin_41854c5/Property?access_token=1c69fed3083478d187d4ce8deb8788ed&$top=1" target="_blank" class="button">
                    Test API URL in Browser
                </a></p>
                <p class="description">This will open the API URL in a new tab. You should see JSON property data if the connection works.</p>
            </div>
            
        </div>
        
        <style>
        .card {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            margin: 20px 0;
            padding: 20px;
        }
        .card h2 {
            margin-top: 0;
        }
        .test-result {
            margin: 15px 0;
            padding: 15px;
            border-radius: 4px;
        }
        .test-success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        .test-error {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        .test-result pre {
            background: rgba(0,0,0,0.05);
            padding: 10px;
            border-radius: 3px;
            overflow-x: auto;
            max-height: 300px;
            overflow-y: auto;
        }
        </style>
        <?php
    }
    
    /**
     * Display test results
     */
    private function display_test_results() {
        $results = get_transient('bridge_debug_results');
        if (!$results) {
            return;
        }
        
        echo '<div class="card">';
        echo '<h2>Test Results</h2>';
        
        foreach ($results as $test => $result) {
            $class = isset($result['success']) && $result['success'] ? 'test-success' : 'test-error';
            echo '<div class="test-result ' . $class . '">';
            echo '<h3>' . ucwords(str_replace('_', ' ', $test)) . '</h3>';
            
            if (isset($result['message'])) {
                echo '<p><strong>Message:</strong> ' . esc_html($result['message']) . '</p>';
            }
            
            if (isset($result['error'])) {
                echo '<p><strong>Error:</strong> ' . esc_html($result['error']) . '</p>';
            }
            
            if (isset($result['data'])) {
                echo '<p><strong>Data:</strong></p>';
                echo '<pre>' . esc_html(print_r($result['data'], true)) . '</pre>';
            }
            
            echo '</div>';
        }
        
        echo '</div>';
        
        // Clear results after displaying
        delete_transient('bridge_debug_results');
    }
    
    /**
     * Test API connection
     */
    private function test_connection() {
        $result = $this->api->test_connection();
        $this->save_test_result('connection_test', $result);
    }
    
    /**
     * Test simple search
     */
    private function test_simple_search() {
        $result = $this->api->search_properties(array(), 1, 5);
        
        if (isset($result['error'])) {
            $this->save_test_result('simple_search', array(
                'success' => false,
                'error' => $result['error']
            ));
        } else {
            $this->save_test_result('simple_search', array(
                'success' => true,
                'message' => 'Found ' . ($result['total_count'] ?? 0) . ' total properties',
                'data' => array(
                    'total_count' => $result['total_count'] ?? 0,
                    'returned_properties' => count($result['properties'] ?? array()),
                    'sample_property' => isset($result['properties'][0]) ? array(
                        'ListingKey' => $result['properties'][0]['ListingKey'] ?? 'N/A',
                        'ListPrice' => $result['properties'][0]['ListPrice'] ?? 'N/A',
                        'City' => $result['properties'][0]['City'] ?? 'N/A',
                        'StandardStatus' => $result['properties'][0]['StandardStatus'] ?? 'N/A'
                    ) : 'No properties returned'
                )
            ));
        }
    }
    
    /**
     * Test filtered search
     */
    private function test_filtered_search() {
        $filters = array(
            'status' => array('Active'),
            'min_price' => 100000
        );
        
        $result = $this->api->search_properties($filters, 1, 5);
        
        if (isset($result['error'])) {
            $this->save_test_result('filtered_search', array(
                'success' => false,
                'error' => $result['error'],
                'filters_used' => $filters
            ));
        } else {
            $this->save_test_result('filtered_search', array(
                'success' => true,
                'message' => 'Found ' . ($result['total_count'] ?? 0) . ' active properties over $100,000',
                'data' => array(
                    'filters_used' => $filters,
                    'total_count' => $result['total_count'] ?? 0,
                    'returned_properties' => count($result['properties'] ?? array())
                )
            ));
        }
    }
    
    /**
     * Test what fields are available
     */
    private function test_available_fields() {
        $result = $this->api->discover_fields();
        
        if (isset($result['error'])) {
            $this->save_test_result('available_fields', array(
                'success' => false,
                'error' => $result['error']
            ));
        } else {
            // Common field mappings to check
            $field_checks = array(
                'DaysOnMarket' => in_array('DaysOnMarket', $result['fields']),
                'CumulativeDaysOnMarket' => in_array('CumulativeDaysOnMarket', $result['fields']),
                'OnMarketDate' => in_array('OnMarketDate', $result['fields']),
                'ListingContractDate' => in_array('ListingContractDate', $result['fields']),
                'PhotosCount' => in_array('PhotosCount', $result['fields']),
                'PricePerSquareFoot' => in_array('PricePerSquareFoot', $result['fields']),
                'LotSizeAcres' => in_array('LotSizeAcres', $result['fields']),
                'GarageSpaces' => in_array('GarageSpaces', $result['fields']),
                'ParkingSpaces' => in_array('ParkingSpaces', $result['fields'])
            );
            
            $this->save_test_result('available_fields', array(
                'success' => true,
                'message' => 'Found ' . $result['total_count'] . ' available fields',
                'data' => array(
                    'total_fields' => $result['total_count'],
                    'field_availability' => $field_checks,
                    'all_fields' => array_slice($result['fields'], 0, 50) // Show first 50 fields
                )
            ));
        }
    }
    
    /**
     * Clear all cache
     */
    private function clear_cache() {
        global $wpdb;
        
        // Delete all Bridge MLS transients
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_bridge_mls_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_bridge_mls_%'");
        
        $this->save_test_result('clear_cache', array(
            'success' => true,
            'message' => 'All Bridge MLS cache cleared successfully'
        ));
    }
    
    /**
     * Save test result
     */
    private function save_test_result($test_name, $result) {
        $results = get_transient('bridge_debug_results') ?: array();
        $results[$test_name] = $result;
        set_transient('bridge_debug_results', $results, 300); // 5 minutes
    }
    
    /**
     * AJAX test handler
     */
    public function ajax_test_api() {
        check_ajax_referer('bridge_debug_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $test_type = sanitize_text_field($_POST['test_type']);
        $this->api = new BridgeAPI();
        
        switch ($test_type) {
            case 'connection':
                $result = $this->api->test_connection();
                break;
            case 'simple':
                $result = $this->api->search_properties(array(), 1, 1);
                break;
            case 'fields':
                $result = $this->api->discover_fields();
                break;
            default:
                $result = array('error' => 'Invalid test type');
        }
        
        wp_send_json_success($result);
    }
}