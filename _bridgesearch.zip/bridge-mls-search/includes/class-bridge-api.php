<?php
/**
 * Bridge API Handler Class - Fixed with Proper Media Support
 */

if (!defined('ABSPATH')) {
    exit;
}

class BridgeAPI {
    
    private $base_url = 'https://api.bridgedataoutput.com/api/v2/OData/shared_mlspin_41854c5/';
    private $access_token = '1c69fed3083478d187d4ce8deb8788ed';
    private $cache_duration = 3600; // 1 hour cache
    
    public function __construct() {
        // Constructor
    }
    
    /**
     * Search properties with filters
     */
    public function search_properties($filters = array(), $page = 1, $per_page = 25) {
        // First, let's test a simple query without filters to ensure basic connectivity
        if (empty($filters)) {
            return $this->simple_property_search($page, $per_page);
        }
        
        $cache_key = 'bridge_mls_search_' . md5(serialize($filters) . $page . $per_page);
        $cached_result = get_transient($cache_key);
        
        if ($cached_result !== false) {
            return $cached_result;
        }
        
        $endpoint = $this->base_url . 'Property';
        
        // Build OData filter string with proper escaping
        $odata_filters = array();
        
        // Property Type filters
        if (!empty($filters['property_types'])) {
            $type_filters = array();
            foreach ($filters['property_types'] as $type) {
                $type_filters[] = "PropertyType eq '" . $this->escape_odata_string($type) . "'";
            }
            if (!empty($type_filters)) {
                $odata_filters[] = '(' . implode(' or ', $type_filters) . ')';
            }
        }
        
        // Status filters - use StandardStatus field
        if (!empty($filters['status'])) {
            $status_filters = array();
            foreach ($filters['status'] as $status) {
                $status_filters[] = "StandardStatus eq '" . $this->escape_odata_string($status) . "'";
            }
            if (!empty($status_filters)) {
                $odata_filters[] = '(' . implode(' or ', $status_filters) . ')';
            }
        }
        
        // Price range - ensure numeric values
        if (!empty($filters['min_price']) && is_numeric($filters['min_price'])) {
            $odata_filters[] = 'ListPrice ge ' . intval($filters['min_price']);
        }
        if (!empty($filters['max_price']) && is_numeric($filters['max_price'])) {
            $odata_filters[] = 'ListPrice le ' . intval($filters['max_price']);
        }
        
        // Bedrooms - ensure numeric
        if (!empty($filters['bedrooms']) && is_numeric($filters['bedrooms'])) {
            $odata_filters[] = 'BedroomsTotal ge ' . intval($filters['bedrooms']);
        }
        
        // Bathrooms - ensure numeric
        if (!empty($filters['bathrooms']) && is_numeric($filters['bathrooms'])) {
            $odata_filters[] = 'BathroomsTotalInteger ge ' . intval($filters['bathrooms']);
        }
        
        // City/Town filters
        if (!empty($filters['cities'])) {
            $city_filters = array();
            foreach ($filters['cities'] as $city) {
                $city_filters[] = "City eq '" . $this->escape_odata_string($city) . "'";
            }
            if (!empty($city_filters)) {
                $odata_filters[] = '(' . implode(' or ', $city_filters) . ')';
            }
        }
        
        // Combine all filters
        $filter_string = implode(' and ', $odata_filters);
        
        // Build query parameters
        $skip = ($page - 1) * $per_page;
        $query_params = array(
            'access_token' => $this->access_token,
            '$top' => $per_page,
            '$skip' => $skip,
            '$count' => 'true',
            '$orderby' => 'ModificationTimestamp desc'
        );
        
        if (!empty($filter_string)) {
            $query_params['$filter'] = $filter_string;
        }
        
        // Select essential fields - removed problematic fields
        $select_fields = array(
            'ListingKey', 'ListPrice', 'BedroomsTotal', 'BathroomsTotalInteger',
            'LivingArea', 'PropertyType', 'StandardStatus', 'City', 'StateOrProvince',
            'PostalCode', 'StreetNumber', 'StreetName', 'PublicRemarks',
            'YearBuilt', 'ModificationTimestamp', 'ListingId', 'OriginalListPrice'
        );
        
        $query_params['$select'] = implode(',', $select_fields);
        
        $result = $this->make_api_request($endpoint, $query_params, $page, $per_page);
        
        // Enhance results with media for each property
        if (isset($result['properties']) && !empty($result['properties'])) {
            foreach ($result['properties'] as &$property) {
                if (!empty($property['ListingKey'])) {
                    $property['media'] = $this->get_property_media($property['ListingKey']);
                    $property['PhotosCount'] = count($property['media']);
                }
            }
        }
        
        return $result;
    }
    
    /**
     * Simple property search without filters for testing connectivity
     */
    private function simple_property_search($page = 1, $per_page = 25) {
        $endpoint = $this->base_url . 'Property';
        
        $skip = ($page - 1) * $per_page;
        $query_params = array(
            'access_token' => $this->access_token,
            '$top' => $per_page,
            '$skip' => $skip,
            '$count' => 'true',
            '$orderby' => 'ModificationTimestamp desc',
            '$select' => 'ListingKey,ListPrice,BedroomsTotal,BathroomsTotalInteger,City,StandardStatus,PropertyType,StreetNumber,StreetName'
        );
        
        $result = $this->make_api_request($endpoint, $query_params, $page, $per_page);
        
        // Enhance results with media for each property
        if (isset($result['properties']) && !empty($result['properties'])) {
            foreach ($result['properties'] as &$property) {
                if (!empty($property['ListingKey'])) {
                    $property['media'] = $this->get_property_media($property['ListingKey']);
                    $property['PhotosCount'] = count($property['media']);
                }
            }
        }
        
        return $result;
    }
    
    /**
     * Make API request with proper error handling
     */
    private function make_api_request($endpoint, $query_params, $page, $per_page) {
        // Build final URL
        $query_string = http_build_query($query_params);
        $url = $endpoint . '?' . $query_string;
        
        // Log the URL for debugging
        error_log('Bridge API Request URL: ' . $url);
        
        // Make API request with extended timeout
        $response = wp_remote_get($url, array(
            'timeout' => 45,
            'headers' => array(
                'Accept' => 'application/json',
                'User-Agent' => 'WordPress Bridge MLS Plugin/1.0'
            )
        ));
        
        if (is_wp_error($response)) {
            error_log('Bridge API Error: ' . $response->get_error_message());
            return array('error' => 'Connection failed: ' . $response->get_error_message());
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        // Log response for debugging
        error_log('Bridge API Response Code: ' . $response_code);
        if ($response_code !== 200) {
            error_log('Bridge API Response Body: ' . $body);
        }
        
        if ($response_code !== 200) {
            $error_message = $this->parse_error_response($body, $response_code);
            return array('error' => $error_message);
        }
        
        $data = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('Bridge API JSON Error: ' . json_last_error_msg());
            return array('error' => 'Invalid JSON response');
        }
        
        $result = array(
            'properties' => $data['value'] ?? array(),
            'total_count' => $data['@odata.count'] ?? 0,
            'page' => $page,
            'per_page' => $per_page,
            'total_pages' => ceil(($data['@odata.count'] ?? 0) / $per_page)
        );
        
        return $result;
    }
    
    /**
     * Get property media (photos, virtual tours) - Bridge API specific
     */
    public function get_property_media($listing_key) {
        if (empty($listing_key)) {
            return array();
        }
        
        $cache_key = 'bridge_mls_media_' . $listing_key;
        $cached_result = get_transient($cache_key);
        
        if ($cached_result !== false) {
            return $cached_result;
        }
        
        $endpoint = $this->base_url . 'Media';
        $query_params = array(
            'access_token' => $this->access_token,
            '$filter' => "ResourceRecordKey eq '" . $this->escape_odata_string($listing_key) . "'",
            '$orderby' => 'Order asc',
            '$select' => 'MediaKey,ResourceRecordKey,MediaURL,MediaType,Order,MediaObjectID'
        );
        
        $query_string = http_build_query($query_params);
        $url = $endpoint . '?' . $query_string;
        
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'headers' => array('Accept' => 'application/json')
        ));
        
        if (is_wp_error($response)) {
            error_log('Bridge Media API Error: ' . $response->get_error_message());
            return array();
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            error_log('Bridge Media API HTTP Error: ' . $response_code);
            return array();
        }
        
        $data = json_decode(wp_remote_retrieve_body($response), true);
        $media = $data['value'] ?? array();
        
        // Cache media for 6 hours
        set_transient($cache_key, $media, 21600);
        
        return $media;
    }
    
    /**
     * Parse error response to get meaningful error message
     */
    private function parse_error_response($body, $response_code) {
        $error_data = json_decode($body, true);
        
        if (json_last_error() === JSON_ERROR_NONE && isset($error_data['error'])) {
            if (isset($error_data['error']['message'])) {
                return 'API Error: ' . $error_data['error']['message'];
            }
        }
        
        // Common error messages based on status codes
        switch ($response_code) {
            case 400:
                return 'Bad Request - Invalid query parameters or syntax';
            case 401:
                return 'Unauthorized - Invalid access token';
            case 403:
                return 'Forbidden - Access denied';
            case 404:
                return 'Not Found - Invalid endpoint or resource';
            case 429:
                return 'Rate Limited - Too many requests';
            case 500:
                return 'Server Error - Internal server error';
            default:
                return 'HTTP Error ' . $response_code;
        }
    }
    
    /**
     * Escape OData string values to prevent syntax errors
     */
    private function escape_odata_string($value) {
        // Remove any existing quotes and escape single quotes
        $value = str_replace("'", "''", trim($value));
        return $value;
    }
    
    /**
     * Test API connectivity with a simple metadata request
     */
    public function test_connection() {
        $endpoint = $this->base_url . '$metadata';
        $url = $endpoint . '?access_token=' . $this->access_token;
        
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'headers' => array(
                'Accept' => 'application/xml',
                'User-Agent' => 'WordPress Bridge MLS Plugin/1.0'
            )
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'error' => $response->get_error_message()
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        
        if ($response_code === 200) {
            return array(
                'success' => true,
                'message' => 'Connection successful'
            );
        } else {
            $body = wp_remote_retrieve_body($response);
            return array(
                'success' => false,
                'error' => 'HTTP ' . $response_code . ': ' . $this->parse_error_response($body, $response_code)
            );
        }
    }
    
    /**
     * Get property details by listing key
     */
    public function get_property_details($listing_key) {
        $cache_key = 'bridge_mls_property_' . $listing_key;
        $cached_result = get_transient($cache_key);
        
        if ($cached_result !== false) {
            return $cached_result;
        }
        
        $endpoint = $this->base_url . 'Property';
        $query_params = array(
            'access_token' => $this->access_token,
            '$filter' => "ListingKey eq '" . $this->escape_odata_string($listing_key) . "'"
        );
        
        $query_string = http_build_query($query_params);
        $url = $endpoint . '?' . $query_string;
        
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'headers' => array(
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            return array('error' => 'API request failed');
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            $body = wp_remote_retrieve_body($response);
            return array('error' => $this->parse_error_response($body, $response_code));
        }
        
        $data = json_decode(wp_remote_retrieve_body($response), true);
        $property = $data['value'][0] ?? null;
        
        if ($property) {
            // Get media for this property
            $property['media'] = $this->get_property_media($property['ListingKey']);
            
            // Cache the result
            set_transient($cache_key, $property, $this->cache_duration);
        }
        
        return $property;
    }
    
    /**
     * Get available towns/cities with simpler query
     */
    public function get_towns($state = 'MA', $coverage_area = 'Eastern Mass') {
        $cache_key = 'bridge_mls_towns_' . $state;
        $cached_result = get_transient($cache_key);
        
        if ($cached_result !== false) {
            return $cached_result;
        }
        
        // Use a simpler approach - just return common MA cities for now
        $ma_cities = array(
            'Boston', 'Cambridge', 'Somerville', 'Newton', 'Brookline',
            'Quincy', 'Lynn', 'Lowell', 'Worcester', 'Springfield',
            'Framingham', 'Waltham', 'Malden', 'Medford', 'Revere',
            'Peabody', 'Methuen', 'Barnstable', 'Pittsfield', 'Taunton'
        );
        
        // Cache for 24 hours
        set_transient($cache_key, $ma_cities, 86400);
        
        return $ma_cities;
    }
    
    /**
     * Get metadata to understand available fields
     */
    public function get_metadata() {
        $cache_key = 'bridge_mls_metadata';
        $cached_result = get_transient($cache_key);
        
        if ($cached_result !== false) {
            return $cached_result;
        }
        
        $endpoint = $this->base_url . '$metadata';
        $url = $endpoint . '?access_token=' . $this->access_token;
        
        $response = wp_remote_get($url, array('timeout' => 30));
        
        if (is_wp_error($response)) {
            return array();
        }
        
        $metadata = wp_remote_retrieve_body($response);
        
        // Cache metadata for 7 days
        set_transient($cache_key, $metadata, 604800);
        
        return $metadata;
    }
    
    /**
     * Discover available fields by getting one property without field selection
     */
    public function discover_fields() {
        $endpoint = $this->base_url . 'Property';
        $query_params = array(
            'access_token' => $this->access_token,
            '$top' => 1
        );
        
        $query_string = http_build_query($query_params);
        $url = $endpoint . '?' . $query_string;
        
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'headers' => array('Accept' => 'application/json')
        ));
        
        if (is_wp_error($response)) {
            return array('error' => $response->get_error_message());
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            $body = wp_remote_retrieve_body($response);
            return array('error' => $this->parse_error_response($body, $response_code));
        }
        
        $data = json_decode(wp_remote_retrieve_body($response), true);
        $property = $data['value'][0] ?? null;
        
        if ($property) {
            $available_fields = array_keys($property);
            sort($available_fields);
            
            return array(
                'success' => true,
                'fields' => $available_fields,
                'total_count' => count($available_fields)
            );
        }
        
        return array('error' => 'No property data returned');
    }
}