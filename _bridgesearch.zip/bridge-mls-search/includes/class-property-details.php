<?php
/**
 * Property Details Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class PropertyDetails {
    
    private $api;
    
    public function __construct() {
        $this->api = new BridgeAPI();
    }
    
    /**
     * Render property details page
     */
    public function render($listing_key) {
        $property = $this->api->get_property_details($listing_key);
        
        if (!$property || isset($property['error'])) {
            return '<div class="bridge-mls-error">Property not found or error loading details.</div>';
        }
        
        ob_start();
        ?>
        
        <div id="bridge-mls-property-details" class="bridge-mls-container">
            
            <!-- Property Header -->
            <div class="property-header">
                <div class="property-title">
                    <h1><?php echo esc_html($this->format_address($property)); ?></h1>
                    <div class="property-status">
                        <span class="status-badge status-<?php echo esc_attr(strtolower($property['StandardStatus'] ?? '')); ?>">
                            <?php echo esc_html($property['StandardStatus'] ?? 'Active'); ?>
                        </span>
                        <?php if (!empty($property['ListingId'])): ?>
                            <span class="mls-number">MLS# <?php echo esc_html($property['ListingId']); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="property-price">
                    <span class="current-price">$<?php echo number_format($property['ListPrice'] ?? 0); ?></span>
                    <?php if (!empty($property['OriginalListPrice']) && $property['OriginalListPrice'] !== $property['ListPrice']): ?>
                        <span class="original-price">Originally $<?php echo number_format($property['OriginalListPrice']); ?></span>
                    <?php endif; ?>
                    <?php if (!empty($property['PricePerSquareFoot'])): ?>
                        <span class="price-per-sqft">$<?php echo number_format($property['PricePerSquareFoot']); ?>/sq ft</span>
                    <?php endif; ?>
                </div>
                
                <div class="property-actions">
                    <button type="button" class="btn btn-primary btn-schedule-showing">Schedule Showing</button>
                    <button type="button" class="btn btn-secondary btn-save-property">Save Property</button>
                    <button type="button" class="btn btn-secondary btn-share-property">Share</button>
                    <button type="button" class="btn btn-secondary btn-print-property">Print</button>
                </div>
            </div>
            
            <!-- Property Media -->
            <div class="property-media">
                <?php $this->render_property_photos($property); ?>
            </div>
            
            <!-- Property Summary -->
            <div class="property-summary">
                <div class="summary-stats">
                    <?php $this->render_property_stats($property); ?>
                </div>
                
                <div class="summary-highlights">
                    <?php $this->render_property_highlights($property); ?>
                </div>
            </div>
            
            <!-- Property Details Tabs -->
            <div class="property-tabs">
                <nav class="tabs-nav">
                    <button class="tab-button active" data-tab="overview">Overview</button>
                    <button class="tab-button" data-tab="details">Details & Features</button>
                    <button class="tab-button" data-tab="location">Location & Schools</button>
                    <button class="tab-button" data-tab="history">Price History</button>
                    <button class="tab-button" data-tab="mortgage">Mortgage Calculator</button>
                </nav>
                
                <div class="tabs-content">
                    <div id="tab-overview" class="tab-panel active">
                        <?php $this->render_overview_tab($property); ?>
                    </div>
                    
                    <div id="tab-details" class="tab-panel">
                        <?php $this->render_details_tab($property); ?>
                    </div>
                    
                    <div id="tab-location" class="tab-panel">
                        <?php $this->render_location_tab($property); ?>
                    </div>
                    
                    <div id="tab-history" class="tab-panel">
                        <?php $this->render_history_tab($property); ?>
                    </div>
                    
                    <div id="tab-mortgage" class="tab-panel">
                        <?php $this->render_mortgage_tab($property); ?>
                    </div>
                </div>
            </div>
            
            <!-- Similar Properties -->
            <div class="similar-properties">
                <h3>Similar Properties</h3>
                <?php $this->render_similar_properties($property); ?>
            </div>
            
            <!-- Contact Information -->
            <div class="property-contact">
                <?php $this->render_contact_info($property); ?>
            </div>
            
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Tab switching
            $('.tab-button').click(function() {
                var tabId = $(this).data('tab');
                $('.tab-button').removeClass('active');
                $('.tab-panel').removeClass('active');
                $(this).addClass('active');
                $('#tab-' + tabId).addClass('active');
            });
            
            // Photo gallery
            $('.property-photo').click(function() {
                var imageUrl = $(this).data('full-url');
                openImageModal(imageUrl);
            });
            
            // Mortgage calculator
            $('#mortgage-form input').on('input', function() {
                calculateMortgage();
            });
        });
        
        function openImageModal(imageUrl) {
            // Implement image modal/lightbox
        }
        
        function calculateMortgage() {
            var price = parseFloat($('#mortgage-price').val()) || 0;
            var downPayment = parseFloat($('#down-payment').val()) || 0;
            var interestRate = parseFloat($('#interest-rate').val()) || 0;
            var loanTerm = parseFloat($('#loan-term').val()) || 30;
            
            var principal = price - downPayment;
            var monthlyRate = interestRate / 100 / 12;
            var numPayments = loanTerm * 12;
            
            var monthlyPayment = principal * (monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / (Math.pow(1 + monthlyRate, numPayments) - 1);
            
            $('#monthly-payment').text('$' + monthlyPayment.toFixed(2));
        }
        </script>
        
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render property photos
     */
    private function render_property_photos($property) {
        $media = $property['media'] ?? array();
        
        if (empty($media)) {
            echo '<div class="no-photos">No photos available for this property.</div>';
            return;
        }
        
        ?>
        <div class="photo-gallery">
            <div class="main-photo">
                <?php if (!empty($media[0])): ?>
                    <img src="<?php echo esc_url($media[0]['MediaURL'] ?? ''); ?>" 
                         alt="Main property photo" 
                         class="property-photo" 
                         data-full-url="<?php echo esc_url($media[0]['MediaURL'] ?? ''); ?>">
                <?php endif; ?>
                
                <div class="photo-counter">
                    1 / <?php echo count($media); ?>
                </div>
            </div>
            
            <?php if (count($media) > 1): ?>
            <div class="photo-thumbnails">
                <?php foreach (array_slice($media, 0, 6) as $index => $photo): ?>
                    <img src="<?php echo esc_url($photo['MediaURL'] ?? ''); ?>" 
                         alt="Property photo <?php echo $index + 1; ?>" 
                         class="thumbnail-photo <?php echo $index === 0 ? 'active' : ''; ?>"
                         data-full-url="<?php echo esc_url($photo['MediaURL'] ?? ''); ?>">
                <?php endforeach; ?>
                
                <?php if (count($media) > 6): ?>
                    <div class="more-photos">
                        +<?php echo count($media) - 6; ?> more
                    </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render property stats
     */
    private function render_property_stats($property) {
        ?>
        <div class="property-stats">
            <div class="stat-item">
                <span class="stat-value"><?php echo $property['BedroomsTotal'] ?? 'N/A'; ?></span>
                <span class="stat-label">Bedrooms</span>
            </div>
            
            <div class="stat-item">
                <span class="stat-value"><?php echo $property['BathroomsTotalInteger'] ?? 'N/A'; ?></span>
                <span class="stat-label">Bathrooms</span>
            </div>
            
            <?php if (!empty($property['LivingArea'])): ?>
            <div class="stat-item">
                <span class="stat-value"><?php echo number_format($property['LivingArea']); ?></span>
                <span class="stat-label">Sq Ft</span>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($property['LotSizeAcres'])): ?>
            <div class="stat-item">
                <span class="stat-value"><?php echo number_format($property['LotSizeAcres'], 2); ?></span>
                <span class="stat-label">Acres</span>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($property['YearBuilt'])): ?>
            <div class="stat-item">
                <span class="stat-value"><?php echo $property['YearBuilt']; ?></span>
                <span class="stat-label">Year Built</span>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($property['DaysOnMarket'])): ?>
            <div class="stat-item">
                <span class="stat-value"><?php echo $property['DaysOnMarket']; ?></span>
                <span class="stat-label">Days on Market</span>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render property highlights
     */
    private function render_property_highlights($property) {
        $highlights = array();
        
        if (!empty($property['PropertyType'])) {
            $highlights[] = $property['PropertyType'];
        }
        
        if (!empty($property['PropertySubType'])) {
            $highlights[] = $property['PropertySubType'];
        }
        
        if (!empty($property['GarageSpaces'])) {
            $highlights[] = $property['GarageSpaces'] . ' Car Garage';
        }
        
        if (!empty($property['PoolFeatures'])) {
            $highlights[] = 'Pool';
        }
        
        if (!empty($property['FireplaceFeatures'])) {
            $highlights[] = 'Fireplace';
        }
        
        if (!empty($highlights)): ?>
        <div class="property-highlights">
            <h4>Property Highlights</h4>
            <ul class="highlights-list">
                <?php foreach ($highlights as $highlight): ?>
                    <li><?php echo esc_html($highlight); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif;
    }
    
    /**
     * Render overview tab
     */
    private function render_overview_tab($property) {
        ?>
        <div class="overview-content">
            <?php if (!empty($property['PublicRemarks'])): ?>
            <div class="property-description">
                <h4>Property Description</h4>
                <p><?php echo nl2br(esc_html($property['PublicRemarks'])); ?></p>
            </div>
            <?php endif; ?>
            
            <div class="property-features">
                <div class="features-grid">
                    <div class="feature-section">
                        <h5>Interior Features</h5>
                        <ul>
                            <?php if (!empty($property['InteriorFeatures'])): ?>
                                <?php foreach (explode(',', $property['InteriorFeatures']) as $feature): ?>
                                    <li><?php echo esc_html(trim($feature)); ?></li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                    
                    <div class="feature-section">
                        <h5>Exterior Features</h5>
                        <ul>
                            <?php if (!empty($property['ExteriorFeatures'])): ?>
                                <?php foreach (explode(',', $property['ExteriorFeatures']) as $feature): ?>
                                    <li><?php echo esc_html(trim($feature)); ?></li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                    
                    <div class="feature-section">
                        <h5>Appliances</h5>
                        <ul>
                            <?php if (!empty($property['Appliances'])): ?>
                                <?php foreach (explode(',', $property['Appliances']) as $appliance): ?>
                                    <li><?php echo esc_html(trim($appliance)); ?></li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render details tab
     */
    private function render_details_tab($property) {
        ?>
        <div class="details-content">
            <div class="details-grid">
                <div class="detail-section">
                    <h5>Property Information</h5>
                    <table class="details-table">
                        <tr><td>Property Type:</td><td><?php echo esc_html($property['PropertyType'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Property Sub Type:</td><td><?php echo esc_html($property['PropertySubType'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Year Built:</td><td><?php echo esc_html($property['YearBuilt'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Total Rooms:</td><td><?php echo esc_html($property['RoomsTotal'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Bedrooms:</td><td><?php echo esc_html($property['BedroomsTotal'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Full Bathrooms:</td><td><?php echo esc_html($property['BathroomsFull'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Half Bathrooms:</td><td><?php echo esc_html($property['BathroomsHalf'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Living Area:</td><td><?php echo !empty($property['LivingArea']) ? number_format($property['LivingArea']) . ' sq ft' : 'N/A'; ?></td></tr>
                    </table>
                </div>
                
                <div class="detail-section">
                    <h5>Lot & Location</h5>
                    <table class="details-table">
                        <tr><td>Lot Size:</td><td><?php echo !empty($property['LotSizeAcres']) ? number_format($property['LotSizeAcres'], 2) . ' acres' : 'N/A'; ?></td></tr>
                        <tr><td>Lot Dimensions:</td><td><?php echo esc_html($property['LotDimensions'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Neighborhood:</td><td><?php echo esc_html($property['Neighborhood'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Subdivision:</td><td><?php echo esc_html($property['Subdivision'] ?? 'N/A'); ?></td></tr>
                        <tr><td>County:</td><td><?php echo esc_html($property['CountyOrParish'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Area:</td><td><?php echo esc_html($property['MLSAreaMajor'] ?? 'N/A'); ?></td></tr>
                    </table>
                </div>
                
                <div class="detail-section">
                    <h5>Parking & Garage</h5>
                    <table class="details-table">
                        <tr><td>Garage Spaces:</td><td><?php echo esc_html($property['GarageSpaces'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Parking Spaces:</td><td><?php echo esc_html($property['ParkingSpaces'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Parking Features:</td><td><?php echo esc_html($property['ParkingFeatures'] ?? 'N/A'); ?></td></tr>
                    </table>
                </div>
                
                <div class="detail-section">
                    <h5>Utilities & Systems</h5>
                    <table class="details-table">
                        <tr><td>Heating:</td><td><?php echo esc_html($property['Heating'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Cooling:</td><td><?php echo esc_html($property['Cooling'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Water Source:</td><td><?php echo esc_html($property['WaterSource'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Sewer:</td><td><?php echo esc_html($property['Sewer'] ?? 'N/A'); ?></td></tr>
                        <tr><td>Electric:</td><td><?php echo esc_html($property['Electric'] ?? 'N/A'); ?></td></tr>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render location tab
     */
    private function render_location_tab($property) {
        ?>
        <div class="location-content">
            <div class="location-map">
                <div id="property-map" style="height: 400px; background: #f0f0f0; display: flex; align-items: center; justify-content: center;">
                    <p>Map would be displayed here using Google Maps or similar service</p>
                </div>
            </div>
            
            <div class="location-details">
                <h5>Location Information</h5>
                <p><strong>Address:</strong> <?php echo esc_html($this->format_address($property)); ?></p>
                <?php if (!empty($property['Latitude']) && !empty($property['Longitude'])): ?>
                    <p><strong>Coordinates:</strong> <?php echo esc_html($property['Latitude']); ?>, <?php echo esc_html($property['Longitude']); ?></p>
                <?php endif; ?>
            </div>
            
            <div class="nearby-schools">
                <h5>Nearby Schools</h5>
                <p>School information would be displayed here using a school district API</p>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render history tab
     */
    private function render_history_tab($property) {
        ?>
        <div class="history-content">
            <h5>Price History</h5>
            <table class="history-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Event</th>
                        <th>Price</th>
                        <th>Change</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($property['OnMarketDate'])): ?>
                    <tr>
                        <td><?php echo date('M j, Y', strtotime($property['OnMarketDate'])); ?></td>
                        <td>Listed</td>
                        <td>$<?php echo number_format($property['OriginalListPrice'] ?? $property['ListPrice']); ?></td>
                        <td>—</td>
                    </tr>
                    <?php endif; ?>
                    
                    <?php if (!empty($property['OriginalListPrice']) && $property['OriginalListPrice'] !== $property['ListPrice']): ?>
                    <tr>
                        <td><?php echo date('M j, Y', strtotime($property['ModificationTimestamp'] ?? 'now')); ?></td>
                        <td>Price Change</td>
                        <td>$<?php echo number_format($property['ListPrice']); ?></td>
                        <td class="<?php echo $property['ListPrice'] < $property['OriginalListPrice'] ? 'decrease' : 'increase'; ?>">
                            <?php 
                            $change = $property['ListPrice'] - $property['OriginalListPrice'];
                            echo ($change > 0 ? '+' : '') . '$' . number_format(abs($change));
                            ?>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    /**
     * Render mortgage calculator tab
     */
    private function render_mortgage_tab($property) {
        $price = $property['ListPrice'] ?? 0;
        ?>
        <div class="mortgage-content">
            <h5>Mortgage Calculator</h5>
            <form id="mortgage-form" class="mortgage-calculator">
                <div class="calc-row">
                    <div class="calc-field">
                        <label for="mortgage-price">Home Price</label>
                        <input type="number" id="mortgage-price" value="<?php echo $price; ?>" step="1000">
                    </div>
                    
                    <div class="calc-field">
                        <label for="down-payment">Down Payment</label>
                        <input type="number" id="down-payment" value="<?php echo round($price * 0.2); ?>" step="1000">
                    </div>
                </div>
                
                <div class="calc-row">
                    <div class="calc-field">
                        <label for="interest-rate">Interest Rate (%)</label>
                        <input type="number" id="interest-rate" value="6.5" step="0.1" min="0" max="20">
                    </div>
                    
                    <div class="calc-field">
                        <label for="loan-term">Loan Term (years)</label>
                        <select id="loan-term">
                            <option value="15">15 years</option>
                            <option value="30" selected>30 years</option>
                        </select>
                    </div>
                </div>
                
                <div class="calc-result">
                    <div class="monthly-payment">
                        <span class="label">Estimated Monthly Payment:</span>
                        <span id="monthly-payment" class="amount">$0</span>
                    </div>
                </div>
            </form>
        </div>
        <?php
    }
    
    /**
     * Render similar properties
     */
    private function render_similar_properties($property) {
        // This would search for similar properties using the API
        echo '<p>Similar properties would be displayed here based on location, price range, and property type.</p>';
    }
    
    /**
     * Render contact information
     */
    private function render_contact_info($property) {
        ?>
        <div class="contact-info">
            <h4>Contact Information</h4>
            <div class="agent-info">
                <p>For more information about this property, please contact your real estate agent.</p>
                
                <div class="contact-actions">
                    <button type="button" class="btn btn-primary">Request Information</button>
                    <button type="button" class="btn btn-secondary">Schedule Showing</button>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Format property address
     */
    private function format_address($property) {
        $parts = array();
        
        if (!empty($property['StreetNumber'])) {
            $parts[] = $property['StreetNumber'];
        }
        
        if (!empty($property['StreetName'])) {
            $parts[] = $property['StreetName'];
        }
        
        if (!empty($property['UnitNumber'])) {
            $parts[] = 'Unit ' . $property['UnitNumber'];
        }
        
        $address = implode(' ', $parts);
        
        if (!empty($property['City'])) {
            $address .= ', ' . $property['City'];
        }
        
        if (!empty($property['StateOrProvince'])) {
            $address .= ', ' . $property['StateOrProvince'];
        }
        
        if (!empty($property['PostalCode'])) {
            $address .= ' ' . $property['PostalCode'];
        }
        
        return $address;
    }
}