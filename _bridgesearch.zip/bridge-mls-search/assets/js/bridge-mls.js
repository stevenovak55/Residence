/**
 * Bridge MLS Plugin JavaScript
 */

jQuery(document).ready(function($) {
    'use strict';
    
    // Initialize the plugin
    BridgeMLS.init();
});

var BridgeMLS = {
    
    /**
     * Initialize the plugin
     */
    init: function() {
        this.initSearchForm();
        this.initResults();
        this.initPropertyDetails();
        this.initQuickFilters();
        this.bindEvents();
    },
    
    /**
     * Initialize search form functionality
     */
    initSearchForm: function() {
        var $ = jQuery;
        
        // Toggle section visibility
        $('.section-header').on('click', function() {
            var $content = $(this).next('.section-content');
            var $icon = $(this).find('.toggle-icon');
            
            $content.slideToggle(300);
            $icon.text($icon.text() === '▼' ? '▲' : '▼');
        });
        
        // Select All checkboxes
        $('#select_all_types').on('change', function() {
            $('input[name="property_types[]"]').prop('checked', this.checked);
        });
        
        $('#select_all_status').on('change', function() {
            $('input[name="status[]"]').prop('checked', this.checked);
        });
        
        // Load towns dynamically
        $('#coverage_area, #state').on('change', function() {
            BridgeMLS.loadTowns();
        });
        
        // Towns search functionality
        $('.towns-search-input').on('input', function() {
            var searchTerm = $(this).val().toLowerCase();
            $('#towns-list .checkbox-item').each(function() {
                var townName = $(this).text().toLowerCase();
                $(this).toggle(townName.includes(searchTerm));
            });
        });
        
        // Add town button
        $('.btn-add').on('click', function() {
            var searchTerm = $('.towns-search-input').val().trim();
            if (searchTerm) {
                BridgeMLS.addTown(searchTerm);
                $('.towns-search-input').val('');
            }
        });
        
        // Remove all towns
        $('.btn-remove-all').on('click', function() {
            $('#towns-list input[type="checkbox"]').prop('checked', false);
        });
        
        // Form validation before submit
        $('#mls-search-form').on('submit', function(e) {
            if (!BridgeMLS.validateSearchForm()) {
                e.preventDefault();
                return false;
            }
        });
        
        // Auto-save search criteria
        $('#mls-search-form input, #mls-search-form select').on('change', function() {
            BridgeMLS.autoSaveSearch();
        });
    },
    
    /**
     * Initialize results functionality
     */
    initResults: function() {
        var $ = jQuery;
        
        // View toggle (grid/list)
        $('.btn-view').on('click', function() {
            var viewType = $(this).data('view');
            $('.btn-view').removeClass('active');
            $(this).addClass('active');
            $('.results-container').removeClass('grid-view list-view').addClass(viewType + '-view');
            
            // Save preference
            localStorage.setItem('mls_view_preference', viewType);
        });
        
        // Load saved view preference
        var savedView = localStorage.getItem('mls_view_preference');
        if (savedView) {
            $('.btn-view[data-view="' + savedView + '"]').click();
        }
        
        // Sort and pagination
        $('#sort_by, #per_page').on('change', function() {
            BridgeMLS.updateResults();
        });
        
        // Toggle map
        $('.btn-toggle-map').on('click', function() {
            $('#results-map-container').slideToggle(400, function() {
                if ($(this).is(':visible') && !BridgeMLS.mapInitialized) {
                    BridgeMLS.initializeMap();
                }
            });
        });
        
        // Property card interactions
        $('.btn-save-property').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var listingKey = $(this).data('listing-key');
            BridgeMLS.saveProperty(listingKey, $(this));
        });
        
        $('.btn-share-property').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var listingKey = $(this).data('listing-key');
            BridgeMLS.shareProperty(listingKey);
        });
        
        // Infinite scroll for results (optional)
        if ($('.results-container').length) {
            BridgeMLS.initInfiniteScroll();
        }
    },
    
    /**
     * Initialize property details functionality
     */
    initPropertyDetails: function() {
        var $ = jQuery;
        
        if (!$('#bridge-mls-property-details').length) {
            return;
        }
        
        // Tab switching
        $('.tab-button').on('click', function() {
            var tabId = $(this).data('tab');
            $('.tab-button').removeClass('active');
            $('.tab-panel').removeClass('active');
            $(this).addClass('active');
            $('#tab-' + tabId).addClass('active');
        });
        
        // Photo gallery
        $('.thumbnail-photo').on('click', function() {
            var imageUrl = $(this).data('full-url');
            $('.main-photo img').attr('src', imageUrl);
            $('.thumbnail-photo').removeClass('active');
            $(this).addClass('active');
            
            // Update photo counter
            var index = $('.thumbnail-photo').index(this) + 1;
            var total = $('.thumbnail-photo').length;
            $('.photo-counter').text(index + ' / ' + total);
        });
        
        // Open image modal/lightbox
        $('.property-photo, .main-photo img').on('click', function() {
            var imageUrl = $(this).data('full-url') || $(this).attr('src');
            BridgeMLS.openImageModal(imageUrl);
        });
        
        // Mortgage calculator
        $('#mortgage-form input, #mortgage-form select').on('input change', function() {
            BridgeMLS.calculateMortgage();
        });
        
        // Initialize mortgage calculator on load
        BridgeMLS.calculateMortgage();
        
        // Schedule showing form
        $('.btn-schedule-showing').on('click', function() {
            BridgeMLS.showScheduleModal();
        });
        
        // Contact forms
        $('.btn-request-info').on('click', function() {
            BridgeMLS.showContactModal();
        });
    },
    
    /**
     * Initialize quick filters
     */
    initQuickFilters: function() {
        var $ = jQuery;
        
        $('.quick-filter').on('change', function() {
            var filterType = $(this).data('filter');
            var value = $(this).val();
            BridgeMLS.applyQuickFilter(filterType, value);
        });
        
        $('.btn-clear-filters').on('click', function() {
            BridgeMLS.clearAllFilters();
        });
    },
    
    /**
     * Bind general events
     */
    bindEvents: function() {
        var $ = jQuery;
        
        // Handle browser back/forward
        window.addEventListener('popstate', function(e) {
            if (e.state && e.state.isMLSSearch) {
                location.reload();
            }
        });
        
        // Keyboard shortcuts
        $(document).on('keydown', function(e) {
            // Escape key to close modals
            if (e.key === 'Escape') {
                BridgeMLS.closeModals();
            }
            
            // Ctrl+S to save search
            if (e.ctrlKey && e.key === 's') {
                e.preventDefault();
                BridgeMLS.saveSearch();
            }
        });
    },
    
    /**
     * Load towns based on state and coverage area
     */
    loadTowns: function() {
        var $ = jQuery;
        var state = $('#state').val();
        var coverageArea = $('#coverage_area').val();
        
        if (!state || !coverageArea) {
            return;
        }
        
        var $townsList = $('#towns-list');
        $townsList.html('<div class="loading">Loading towns...</div>');
        
        $.ajax({
            url: bridge_mls_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'mls_get_towns',
                nonce: bridge_mls_ajax.nonce,
                state: state,
                coverage_area: coverageArea
            },
            success: function(response) {
                if (response.success && response.data) {
                    BridgeMLS.renderTownsList(response.data);
                } else {
                    $townsList.html('<div class="error">Failed to load towns</div>');
                }
            },
            error: function() {
                $townsList.html('<div class="error">Failed to load towns</div>');
            }
        });
    },
    
    /**
     * Render towns list
     */
    renderTownsList: function(towns) {
        var $ = jQuery;
        var $townsList = $('#towns-list');
        var html = '';
        
        $.each(towns, function(index, town) {
            html += '<label class="checkbox-item">' +
                   '<input type="checkbox" name="cities[]" value="' + town + '"> ' +
                   town +
                   '</label>';
        });
        
        $townsList.html(html);
    },
    
    /**
     * Add a town to the list
     */
    addTown: function(townName) {
        var $ = jQuery;
        var $townsList = $('#towns-list');
        
        // Check if town already exists
        var exists = false;
        $townsList.find('input[name="cities[]"]').each(function() {
            if ($(this).val().toLowerCase() === townName.toLowerCase()) {
                exists = true;
                return false;
            }
        });
        
        if (!exists) {
            var html = '<label class="checkbox-item">' +
                      '<input type="checkbox" name="cities[]" value="' + townName + '" checked> ' +
                      townName +
                      '</label>';
            $townsList.append(html);
        }
    },
    
    /**
     * Validate search form
     */
    validateSearchForm: function() {
        var $ = jQuery;
        var isValid = true;
        var errors = [];
        
        // Check if at least one search criteria is provided
        var hasPropertyType = $('input[name="property_types[]"]:checked').length > 0;
        var hasCity = $('input[name="cities[]"]:checked').length > 0;
        var hasPrice = $('#min_price').val() || $('#max_price').val();
        var hasKeywords = $('#keywords').val().trim();
        var hasAddress = $('#street_name').val().trim() || $('#zip_code').val().trim();
        
        if (!hasPropertyType && !hasCity && !hasPrice && !hasKeywords && !hasAddress) {
            errors.push('Please provide at least one search criteria');
            isValid = false;
        }
        
        // Validate price range
        var minPrice = parseFloat($('#min_price').val()) || 0;
        var maxPrice = parseFloat($('#max_price').val()) || 0;
        
        if (minPrice > 0 && maxPrice > 0 && minPrice >= maxPrice) {
            errors.push('Minimum price must be less than maximum price');
            isValid = false;
        }
        
        // Show errors if any
        if (!isValid) {
            alert('Please correct the following errors:\n\n' + errors.join('\n'));
        }
        
        return isValid;
    },
    
    /**
     * Auto-save search criteria
     */
    autoSaveSearch: function() {
        var $ = jQuery;
        var formData = $('#mls-search-form').serializeArray();
        var searchData = {};
        
        $.each(formData, function(i, field) {
            if (searchData[field.name]) {
                if (Array.isArray(searchData[field.name])) {
                    searchData[field.name].push(field.value);
                } else {
                    searchData[field.name] = [searchData[field.name], field.value];
                }
            } else {
                searchData[field.name] = field.value;
            }
        });
        
        localStorage.setItem('mls_auto_save', JSON.stringify(searchData));
    },
    
    /**
     * Load auto-saved search
     */
    loadAutoSavedSearch: function() {
        var $ = jQuery;
        var savedData = localStorage.getItem('mls_auto_save');
        
        if (savedData) {
            try {
                var searchData = JSON.parse(savedData);
                
                $.each(searchData, function(name, value) {
                    var $field = $('[name="' + name + '"]');
                    
                    if ($field.attr('type') === 'checkbox' || $field.attr('type') === 'radio') {
                        if (Array.isArray(value)) {
                            $.each(value, function(i, val) {
                                $field.filter('[value="' + val + '"]').prop('checked', true);
                            });
                        } else {
                            $field.filter('[value="' + value + '"]').prop('checked', true);
                        }
                    } else {
                        $field.val(value);
                    }
                });
            } catch (e) {
                console.error('Error loading auto-saved search:', e);
            }
        }
    },
    
    /**
     * Update results with current settings
     */
    updateResults: function() {
        var $ = jQuery;
        var currentUrl = new URL(window.location);
        
        currentUrl.searchParams.set('sort_by', $('#sort_by').val());
        currentUrl.searchParams.set('per_page', $('#per_page').val());
        currentUrl.searchParams.set('page', '1'); // Reset to first page
        
        // Add to browser history
        history.pushState({isMLSSearch: true}, '', currentUrl.toString());
        
        window.location.href = currentUrl.toString();
    },
    
    /**
     * Apply quick filter
     */
    applyQuickFilter: function(filterType, value) {
        var $ = jQuery;
        var currentUrl = new URL(window.location);
        
        if (filterType === 'price_range' && value) {
            var parts = value.split('-');
            if (parts[0]) currentUrl.searchParams.set('min_price', parts[0]);
            if (parts[1]) currentUrl.searchParams.set('max_price', parts[1]);
        } else if (value) {
            currentUrl.searchParams.set(filterType, value);
        } else {
            currentUrl.searchParams.delete(filterType);
        }
        
        currentUrl.searchParams.set('page', '1');
        
        history.pushState({isMLSSearch: true}, '', currentUrl.toString());
        window.location.href = currentUrl.toString();
    },
    
    /**
     * Clear all filters
     */
    clearAllFilters: function() {
        var $ = jQuery;
        var baseUrl = window.location.pathname;
        
        history.pushState({isMLSSearch: true}, '', baseUrl);
        window.location.href = baseUrl;
    },
    
    /**
     * Save property to favorites
     */
    saveProperty: function(listingKey, $button) {
        var $ = jQuery;
        
        $.ajax({
            url: bridge_mls_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'mls_save_property',
                nonce: bridge_mls_ajax.nonce,
                listing_key: listingKey
            },
            beforeSend: function() {
                $button.prop('disabled', true).text('Saving...');
            },
            success: function(response) {
                if (response.success) {
                    $button.addClass('saved').text('Saved');
                    BridgeMLS.showNotification('Property saved to favorites', 'success');
                } else {
                    BridgeMLS.showNotification('Failed to save property', 'error');
                }
            },
            error: function() {
                BridgeMLS.showNotification('Failed to save property', 'error');
            },
            complete: function() {
                setTimeout(function() {
                    $button.prop('disabled', false).text('Save');
                }, 2000);
            }
        });
    },
    
    /**
     * Share property
     */
    shareProperty: function(listingKey) {
        var propertyUrl = window.location.origin + '/mls-property/' + listingKey + '/';
        
        if (navigator.share) {
            // Use native sharing if available
            navigator.share({
                title: 'Check out this property',
                url: propertyUrl
            });
        } else {
            // Fallback to copy to clipboard
            this.copyToClipboard(propertyUrl);
            this.showNotification('Property URL copied to clipboard', 'success');
        }
    },
    
    /**
     * Copy text to clipboard
     */
    copyToClipboard: function(text) {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text);
        } else {
            // Fallback for older browsers
            var textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
        }
    },
    
    /**
     * Initialize infinite scroll
     */
    initInfiniteScroll: function() {
        var $ = jQuery;
        var loading = false;
        var currentPage = parseInt($('.pagination .active .page-link').text()) || 1;
        var totalPages = $('.pagination .page-link:last').prev().text() || 1;
        
        $(window).on('scroll', function() {
            if (loading || currentPage >= totalPages) {
                return;
            }
            
            var scrollTop = $(window).scrollTop();
            var windowHeight = $(window).height();
            var documentHeight = $(document).height();
            
            if (scrollTop + windowHeight >= documentHeight - 200) {
                loading = true;
                BridgeMLS.loadMoreResults(currentPage + 1);
            }
        });
    },
    
    /**
     * Load more results for infinite scroll
     */
    loadMoreResults: function(page) {
        var $ = jQuery;
        var currentUrl = new URL(window.location);
        currentUrl.searchParams.set('page', page);
        
        $.get(currentUrl.toString())
            .done(function(data) {
                var $newProperties = $(data).find('.property-card');
                $('.properties-grid').append($newProperties);
                
                currentPage = page;
                loading = false;
            })
            .fail(function() {
                loading = false;
                BridgeMLS.showNotification('Failed to load more results', 'error');
            });
    },
    
    /**
     * Initialize map
     */
    initializeMap: function() {
        // This would integrate with Google Maps or another mapping service
        // For now, just mark as initialized
        this.mapInitialized = true;
        
        // Example Google Maps integration:
        /*
        var map = new google.maps.Map(document.getElementById('results-map'), {
            zoom: 10,
            center: {lat: 42.3601, lng: -71.0589} // Boston
        });
        
        // Add markers for each property
        $('.property-card').each(function() {
            var lat = $(this).data('latitude');
            var lng = $(this).data('longitude');
            
            if (lat && lng) {
                var marker = new google.maps.Marker({
                    position: {lat: parseFloat(lat), lng: parseFloat(lng)},
                    map: map,
                    title: $(this).find('.property-address').text()
                });
            }
        });
        */
    },
    
    /**
     * Calculate mortgage payment
     */
    calculateMortgage: function() {
        var $ = jQuery;
        var price = parseFloat($('#mortgage-price').val()) || 0;
        var downPayment = parseFloat($('#down-payment').val()) || 0;
        var interestRate = parseFloat($('#interest-rate').val()) || 0;
        var loanTerm = parseFloat($('#loan-term').val()) || 30;
        
        if (price <= 0 || downPayment < 0 || interestRate < 0) {
            $('#monthly-payment').text('$0');
            return;
        }
        
        var principal = price - downPayment;
        var monthlyRate = interestRate / 100 / 12;
        var numPayments = loanTerm * 12;
        
        var monthlyPayment = 0;
        if (monthlyRate > 0) {
            monthlyPayment = principal * (monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / 
                           (Math.pow(1 + monthlyRate, numPayments) - 1);
        } else {
            monthlyPayment = principal / numPayments;
        }
        
        $('#monthly-payment').text('$' + monthlyPayment.toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }));
    },
    
    /**
     * Open image modal/lightbox
     */
    openImageModal: function(imageUrl) {
        var $ = jQuery;
        
        // Create modal if it doesn't exist
        if (!$('#image-modal').length) {
            var modalHtml = 
                '<div id="image-modal" class="image-modal" style="display: none;">' +
                '  <div class="modal-backdrop"></div>' +
                '  <div class="modal-content">' +
                '    <button class="modal-close">&times;</button>' +
                '    <img class="modal-image" src="" alt="Property Image">' +
                '  </div>' +
                '</div>';
            
            $('body').append(modalHtml);
            
            // Bind close events
            $('#image-modal .modal-close, #image-modal .modal-backdrop').on('click', function() {
                $('#image-modal').fadeOut(300);
            });
        }
        
        $('#image-modal .modal-image').attr('src', imageUrl);
        $('#image-modal').fadeIn(300);
    },
    
    /**
     * Show schedule showing modal
     */
    showScheduleModal: function() {
        // Implement schedule showing modal
        alert('Schedule showing functionality would be implemented here');
    },
    
    /**
     * Show contact modal
     */
    showContactModal: function() {
        // Implement contact modal
        alert('Contact form would be implemented here');
    },
    
    /**
     * Close all modals
     */
    closeModals: function() {
        var $ = jQuery;
        $('.modal').fadeOut(300);
    },
    
    /**
     * Save search
     */
    saveSearch: function() {
        // Implement save search functionality
        alert('Save search functionality would be implemented here');
    },
    
    /**
     * Show notification
     */
    showNotification: function(message, type) {
        var $ = jQuery;
        type = type || 'info';
        
        // Create notification if it doesn't exist
        if (!$('#mls-notifications').length) {
            $('body').append('<div id="mls-notifications"></div>');
        }
        
        var notificationClass = 'notification notification-' + type;
        var $notification = $('<div class="' + notificationClass + '">' + message + '</div>');
        
        $('#mls-notifications').append($notification);
        
        // Auto-remove after 5 seconds
        setTimeout(function() {
            $notification.fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
        
        // Allow manual close
        $notification.on('click', function() {
            $(this).fadeOut(300, function() {
                $(this).remove();
            });
        });
    }
};

// Additional CSS for notifications and modals (can be moved to CSS file)
var additionalStyles = `
<style>
#mls-notifications {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 10000;
}

.notification {
    background: #333;
    color: white;
    padding: 15px 20px;
    margin-bottom: 10px;
    border-radius: 4px;
    cursor: pointer;
    min-width: 250px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
}

.notification-success { background: #28a745; }
.notification-error { background: #dc3545; }
.notification-warning { background: #ffc107; color: #333; }
.notification-info { background: #17a2b8; }

.image-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 10000;
}

.modal-backdrop {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.8);
}

.modal-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    max-width: 90%;
    max-height: 90%;
}

.modal-close {
    position: absolute;
    top: -40px;
    right: 0;
    background: none;
    border: none;
    color: white;
    font-size: 30px;
    cursor: pointer;
    z-index: 1;
}

.modal-image {
    max-width: 100%;
    max-height: 80vh;
    border-radius: 8px;
}
</style>
`;

jQuery(document).ready(function() {
    jQuery('head').append(additionalStyles);
});