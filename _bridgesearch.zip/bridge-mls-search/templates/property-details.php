<?php
/**
 * Template for Property Details Page
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Get listing key from URL
$listing_key = get_query_var('mls_property');

if (empty($listing_key)) {
    wp_redirect(home_url('/mls-search/'));
    exit;
}

get_header(); ?>

<div class="property-details-page">
    <div class="container">
        
        <!-- Breadcrumb Navigation -->
        <nav class="breadcrumb-nav">
            <ol class="breadcrumb">
                <li><a href="<?php echo home_url(); ?>">Home</a></li>
                <li><a href="<?php echo home_url('/mls-search/'); ?>">Property Search</a></li>
                <li class="active">Property Details</li>
            </ol>
        </nav>
        
        <!-- Property Details Content -->
        <?php
        $property_details = new PropertyDetails();
        echo $property_details->render($listing_key);
        ?>
        
        <!-- Back to Search -->
        <div class="back-to-search">
            <a href="<?php echo wp_get_referer() ?: home_url('/mls-search/'); ?>" class="btn btn-secondary">
                <i class="icon-arrow-left"></i> Back to Search Results
            </a>
            
            <a href="<?php echo home_url('/mls-search/'); ?>" class="btn btn-outline">
                New Search
            </a>
        </div>
        
    </div>
</div>

<style>
.property-details-page {
    margin: 20px 0 40px 0;
}

.breadcrumb-nav {
    margin-bottom: 30px;
}

.breadcrumb {
    display: flex;
    list-style: none;
    padding: 0;
    margin: 0;
    background: #f8f9fa;
    border-radius: 4px;
    padding: 10px 15px;
}

.breadcrumb li {
    display: flex;
    align-items: center;
}

.breadcrumb li:not(:last-child)::after {
    content: '>';
    margin: 0 10px;
    color: #6c757d;
}

.breadcrumb a {
    color: #007cba;
    text-decoration: none;
}

.breadcrumb a:hover {
    text-decoration: underline;
}

.breadcrumb .active {
    color: #6c757d;
}

.back-to-search {
    display: flex;
    gap: 15px;
    justify-content: center;
    margin-top: 40px;
    padding-top: 30px;
    border-top: 1px solid #e9ecef;
}

.btn-outline {
    background: transparent;
    color: #007cba;
    border: 1px solid #007cba;
}

.btn-outline:hover {
    background: #007cba;
    color: white;
}

@media (max-width: 768px) {
    .back-to-search {
        flex-direction: column;
        align-items: center;
    }
    
    .back-to-search .btn {
        width: 200px;
        text-align: center;
    }
}
</style>

<!-- Schema.org structured data for SEO -->
<?php
$api = new BridgeAPI();
$property = $api->get_property_details($listing_key);

if ($property && !isset($property['error'])):
    $address = array(
        'streetAddress' => trim(($property['StreetNumber'] ?? '') . ' ' . ($property['StreetName'] ?? '')),
        'addressLocality' => $property['City'] ?? '',
        'addressRegion' => $property['StateOrProvince'] ?? '',
        'postalCode' => $property['PostalCode'] ?? '',
        'addressCountry' => 'US'
    );
    
    $schema = array(
        '@context' => 'https://schema.org',
        '@type' => 'RealEstateListing',
        'name' => implode(' ', array_filter(array($property['StreetNumber'] ?? '', $property['StreetName'] ?? ''))),
        'description' => $property['PublicRemarks'] ?? '',
        'url' => home_url('/mls-property/' . $listing_key . '/'),
        'price' => $property['ListPrice'] ?? 0,
        'priceCurrency' => 'USD',
        'address' => $address,
        'geo' => array(
            '@type' => 'GeoCoordinates',
            'latitude' => $property['Latitude'] ?? '',
            'longitude' => $property['Longitude'] ?? ''
        ),
        'floorSize' => array(
            '@type' => 'QuantitativeValue',
            'value' => $property['LivingArea'] ?? '',
            'unitText' => 'square feet'
        ),
        'numberOfRooms' => $property['RoomsTotal'] ?? '',
        'numberOfBedrooms' => $property['BedroomsTotal'] ?? '',
        'numberOfBathroomsTotal' => $property['BathroomsTotalInteger'] ?? '',
        'yearBuilt' => $property['YearBuilt'] ?? '',
        'propertyID' => $property['ListingId'] ?? $listing_key
    );
    
    if (!empty($property['media'])) {
        $images = array();
        foreach ($property['media'] as $media) {
            if (!empty($media['MediaURL'])) {
                $images[] = $media['MediaURL'];
            }
        }
        if (!empty($images)) {
            $schema['image'] = $images;
        }
    }
    ?>
    
    <script type="application/ld+json">
    <?php echo json_encode($schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES); ?>
    </script>
    
    <!-- Open Graph meta tags for social sharing -->
    <meta property="og:title" content="<?php echo esc_attr(implode(' ', array_filter(array($property['StreetNumber'] ?? '', $property['StreetName'] ?? '')))); ?>">
    <meta property="og:description" content="<?php echo esc_attr(wp_trim_words($property['PublicRemarks'] ?? '', 30)); ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo home_url('/mls-property/' . $listing_key . '/'); ?>">
    <?php if (!empty($property['media'][0]['MediaURL'])): ?>
        <meta property="og:image" content="<?php echo esc_url($property['media'][0]['MediaURL']); ?>">
    <?php endif; ?>
    
    <!-- Twitter Card meta tags -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo esc_attr(implode(' ', array_filter(array($property['StreetNumber'] ?? '', $property['StreetName'] ?? '')))); ?>">
    <meta name="twitter:description" content="<?php echo esc_attr(wp_trim_words($property['PublicRemarks'] ?? '', 30)); ?>">
    <?php if (!empty($property['media'][0]['MediaURL'])): ?>
        <meta name="twitter:image" content="<?php echo esc_url($property['media'][0]['MediaURL']); ?>">
    <?php endif; ?>

<?php endif; ?>

<?php get_footer(); ?>