<?php
/**
 * Template for MLS Search Page - Fixed Version
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Ensure we have access to WordPress functions
if (!function_exists('get_header')) {
    // Load WordPress
    require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');
}

// Get the current theme's header
get_header(); 

// Enqueue plugin styles and scripts
wp_enqueue_style('bridge-mls-style');
wp_enqueue_script('bridge-mls-script');
?>

<div class="mls-search-page">
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 20px;">
        
        <!-- Page Header -->
        <div class="page-header" style="text-align: center; margin-bottom: 40px;">
            <h1 style="font-size: 2.5rem; color: #333; margin-bottom: 10px;">Property Search</h1>
            <p style="font-size: 1.1rem; color: #666; margin: 0;">Find your perfect home using our advanced MLS search</p>
        </div>
        
        <!-- Search Form -->
        <div class="search-form-container" style="margin-bottom: 40px;">
            <?php
            if (class_exists('SearchForm')) {
                $search_form = new SearchForm();
                echo $search_form->render(array(
                    'show_additional_criteria' => true,
                    'redirect_url' => home_url('/mls-search/')
                ));
            } else {
                echo '<div class="error">Search form class not found. Please check plugin installation.</div>';
            }
            ?>
        </div>
        
        <!-- Search Results -->
        <?php if (!empty($_GET) && array_filter($_GET)): ?>
            <div class="search-results-container" style="margin-top: 40px;">
                <?php
                if (class_exists('ResultsDisplay')) {
                    $results_display = new ResultsDisplay();
                    echo $results_display->render(array(
                        'per_page' => $_GET['per_page'] ?? 25,
                        'view_type' => $_GET['view'] ?? 'grid',
                        'show_map' => true,
                        'show_filters' => true
                    ));
                } else {
                    echo '<div class="error">Results display class not found. Please check plugin installation.</div>';
                }
                ?>
            </div>
        <?php else: ?>
            <div class="no-search-message" style="text-align: center; padding: 60px 20px; background: #f8f9fa; border-radius: 8px; margin: 40px 0;">
                <h3 style="font-size: 1.8rem; color: #333; margin-bottom: 15px;">Start Your Property Search</h3>
                <p style="font-size: 1.1rem; color: #666; margin-bottom: 30px;">Use the search form above to find properties that match your criteria.</p>
                
                <div class="quick-search-suggestions" style="max-width: 600px; margin: 0 auto;">
                    <h4 style="font-size: 1.2rem; color: #333; margin-bottom: 20px;">Popular Searches:</h4>
                    <div class="suggestion-links" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;">
                        <a href="?property_types[]=RES&cities[]=Boston&min_price=400000&max_price=800000" class="suggestion-link" style="display: block; padding: 15px 20px; background: white; border: 1px solid #e9ecef; border-radius: 6px; color: #007cba; text-decoration: none; font-weight: 500; transition: all 0.2s ease;">
                            Boston Homes $400K-$800K
                        </a>
                        <a href="?property_types[]=CND&cities[]=Cambridge&bedrooms=2" class="suggestion-link" style="display: block; padding: 15px 20px; background: white; border: 1px solid #e9ecef; border-radius: 6px; color: #007cba; text-decoration: none; font-weight: 500; transition: all 0.2s ease;">
                            Cambridge Condos 2+ Bedrooms
                        </a>
                        <a href="?property_types[]=RES&bedrooms=3&bathrooms=2&min_sqft=1500" class="suggestion-link" style="display: block; padding: 15px 20px; background: white; border: 1px solid #e9ecef; border-radius: 6px; color: #007cba; text-decoration: none; font-weight: 500; transition: all 0.2s ease;">
                            3BR/2BA Homes 1500+ Sq Ft
                        </a>
                        <a href="?property_types[]=LND&min_acres=1" class="suggestion-link" style="display: block; padding: 15px 20px; background: white; border: 1px solid #e9ecef; border-radius: 6px; color: #007cba; text-decoration: none; font-weight: 500; transition: all 0.2s ease;">
                            Land 1+ Acres
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Featured Properties or Recent Listings -->
        <?php if (empty($_GET) || !array_filter($_GET)): ?>
            <div class="featured-properties" style="margin-top: 60px; padding-top: 40px; border-top: 1px solid #e9ecef;">
                <h3 style="text-align: center; font-size: 2rem; color: #333; margin-bottom: 10px;">Recent Listings</h3>
                <p style="text-align: center; color: #666; margin-bottom: 40px;">Check out some of our newest properties on the market</p>
                
                <?php
                // Get recent listings
                if (class_exists('BridgeAPI')) {
                    $api = new BridgeAPI();
                    $recent_listings = $api->search_properties(array(), 1, 6);
                    
                    if (!empty($recent_listings['properties']) && !isset($recent_listings['error'])):
                    ?>
                        <div class="featured-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 30px; margin-bottom: 40px;">
                            <?php
                            if (class_exists('ResultsDisplay')) {
                                $results_display = new ResultsDisplay();
                                foreach (array_slice($recent_listings['properties'], 0, 6) as $property) {
                                    $results_display->render_property_card($property, 'grid');
                                }
                            }
                            ?>
                        </div>
                        
                        <div class="view-all-link" style="text-align: center;">
                            <a href="?status[]=Active" class="btn btn-primary" style="display: inline-block; padding: 10px 20px; background-color: #007cba; color: white; text-decoration: none; border-radius: 4px;">View All Active Listings</a>
                        </div>
                    <?php 
                    elseif (isset($recent_listings['error'])):
                    ?>
                        <div class="error-message" style="text-align: center; color: #721c24; background: #f8d7da; padding: 15px; border-radius: 4px;">
                            Unable to load recent listings: <?php echo esc_html($recent_listings['error']); ?>
                        </div>
                    <?php endif;
                } else {
                    echo '<div class="error">BridgeAPI class not found. Please check plugin installation.</div>';
                }
                ?>
            </div>
        <?php endif; ?>
        
    </div>
</div>

<style>
.suggestion-link:hover {
    background: #007cba !important;
    color: white !important;
    text-decoration: none !important;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 124, 186, 0.2);
}

@media (max-width: 768px) {
    .page-header h1 {
        font-size: 2rem !important;
    }
    
    .suggestion-links {
        grid-template-columns: 1fr !important;
    }
    
    .featured-grid {
        grid-template-columns: 1fr !important;
    }
    
    .container {
        padding: 15px !important;
    }
}
</style>

<?php 
// Get the current theme's footer
get_footer(); 
?>